import { Badge, Reward, Task, TaskDifficulty, Quiz, Meeting, Competition, Message, Program, LearningResource, FaqItem } from "./types";

export const MOCK_TASKS: Task[] = [
  {
    id: 't1',
    title: 'Beach Cleanup Initiative',
    description: 'Spend 30 minutes collecting plastic waste from the local shoreline. Ensure you wear gloves and use separate bags for recyclables.',
    category: 'Conservation',
    difficulty: TaskDifficulty.MEDIUM,
    points: 150,
    locationRequired: true,
    steps: ['Arrive at beach', 'Collect waste', 'Sort recyclables', 'Take photo of collection'],
    imageUrl: 'https://picsum.photos/400/300',
    isPriority: false,
    createdAt: Date.now() - 100000000, // A few days ago
    quiz: {
        id: 'q_t1',
        title: 'Ocean Conservation Quiz',
        description: 'Test your knowledge on marine debris.',
        rewardPoints: 50,
        questions: [
            {
                id: 'qt1_1',
                text: 'What is the most common type of marine debris?',
                options: ['Glass', 'Plastic', 'Metal', 'Wood'],
                correctAnswer: 1
            },
            {
                id: 'qt1_2',
                text: 'How long can a plastic bottle last in the ocean?',
                options: ['1 year', '50 years', '450 years', 'Forever'],
                correctAnswer: 2
            }
        ]
    }
  },
  {
    id: 't2',
    title: 'Plant a Tree',
    description: 'Plant a native tree species in your garden or a designated community area. This helps sequester carbon and supports local wildlife.',
    category: 'Nature',
    difficulty: TaskDifficulty.HARD,
    points: 300,
    locationRequired: true,
    steps: ['Select native sapling', 'Dig hole', 'Plant and water', 'Take photo with tree'],
    imageUrl: 'https://picsum.photos/401/300',
    isPriority: false,
    createdAt: Date.now() - 50000000
  },
  {
    id: 't3',
    title: 'Recycling Sort',
    description: 'Correctly sort your household waste for an entire week. Learn the local recycling codes.',
    category: 'Recycling',
    difficulty: TaskDifficulty.EASY,
    points: 50,
    locationRequired: false,
    steps: ['Set up bins', 'Sort waste daily', 'Take photo of sorted bins'],
    imageUrl: 'https://picsum.photos/402/300',
    isPriority: false,
    createdAt: Date.now() - 2000000
  }
];

export const MOCK_BADGES: Badge[] = [
  {
    id: 'b1',
    name: 'Eco Starter',
    description: 'Completed your first task',
    icon: '🌱',
    requiredPoints: 50,
    category: 'Impact'
  },
  {
    id: 'b2',
    name: 'Waste Warrior',
    description: 'Earned 500 points',
    icon: '♻️',
    requiredPoints: 500,
    category: 'Impact'
  },
  {
    id: 'b3',
    name: 'Forest Guardian',
    description: 'Earned 1000 points',
    icon: '🌳',
    requiredPoints: 1000,
    category: 'Impact'
  },
  {
    id: 'b4',
    name: 'Knowledge Seeker',
    description: 'Completed 5 Quizzes',
    icon: '📚',
    requiredPoints: 300,
    category: 'Learning'
  },
  {
    id: 'b5',
    name: 'Community Leader',
    description: 'Referred 5 friends',
    icon: '🤝',
    requiredPoints: 1500,
    category: 'Community'
  }
];

export const MOCK_REWARDS: Reward[] = [
  {
    id: 'r1',
    title: 'Online Sustainability Course',
    cost: 500,
    description: 'Access to premium educational content on climate change.',
    type: 'COURSE'
  },
  {
    id: 'r2',
    title: 'Plant 10 Real Trees',
    cost: 1000,
    description: 'Donation to global reforestation partners in your name.',
    type: 'DONATION'
  },
  {
    id: 'r3',
    title: 'Reusable Water Bottle',
    cost: 300,
    description: 'High quality steel bottle to reduce plastic use.',
    type: 'ITEM'
  }
];

export const MOCK_QUIZZES: Quiz[] = [
  {
    id: 'q1',
    title: 'Recycling Mastery',
    description: 'Test your knowledge on recycling symbols, separation techniques, and non-recyclable items.',
    rewardPoints: 100,
    questions: [
      {
        id: 'qq1',
        text: 'Which of the following items is generally NOT recyclable in standard curbside bins?',
        options: ['Plastic Water Bottles', 'Cardboard Boxes', 'Plastic Grocery Bags', 'Aluminum Cans'],
        correctAnswer: 2
      },
      {
        id: 'qq2',
        text: 'What does the recycling symbol with the number 1 (PETE) usually indicate?',
        options: ['Polystyrene (Styrofoam)', 'Polyethylene Terephthalate (Soda bottles)', 'Polyvinyl Chloride (Pipes)', 'Polypropylene (Yogurt cups)'],
        correctAnswer: 1
      },
      {
        id: 'qq3',
        text: 'Why is it important to rinse food containers before recycling?',
        options: ['It smells better', 'Food residue can contaminate an entire batch of recyclables', 'It makes them lighter', 'It is not actually important'],
        correctAnswer: 1
      }
    ]
  },
  {
    id: 'q2',
    title: 'Climate Change 101',
    description: 'Understand the basics of the greenhouse effect and renewable energy.',
    rewardPoints: 150,
    questions: [
      {
        id: 'qq4',
        text: 'Which gas is most commonly associated with the greenhouse effect?',
        options: ['Oxygen', 'Nitrogen', 'Carbon Dioxide', 'Argon'],
        correctAnswer: 2
      },
      {
        id: 'qq5',
        text: 'Which of these is a renewable energy source?',
        options: ['Coal', 'Natural Gas', 'Solar Power', 'Nuclear Fission'],
        correctAnswer: 2
      }
    ]
  }
];

export const MOCK_MEETINGS: Meeting[] = [
  {
    id: 'm1',
    title: 'Monthly Eco-Club Sync',
    platform: 'Zoom',
    date: Date.now() + 86400000 * 2,
    time: '4:00 PM',
    description: 'Discussing the upcoming campus green initiative and assigning roles for the recycling drive.',
    link: 'https://zoom.us/j/example'
  },
  {
    id: 'm2',
    title: 'Guest Lecture: Sustainable Cities',
    platform: 'Google Meet',
    date: Date.now() + 86400000 * 5,
    time: '2:00 PM',
    description: 'Prof. Alcott shares insights on urban gardening and waste reduction strategies.',
    link: 'https://meet.google.com/example'
  }
];

export const MOCK_COMPETITIONS: Competition[] = [
  {
    id: 'c1',
    title: 'Zero Waste Week Challenge',
    status: 'Active',
    description: 'Reduce your household waste to the absolute minimum for 7 days. Track your progress.',
    prize: 'Eco-Friendly Starter Kit',
    endDate: Date.now() + 86400000 * 7
  },
  {
    id: 'c2',
    title: 'Upcycling Art Contest',
    status: 'Upcoming',
    description: 'Create art pieces using only recycled materials. Best creative piece wins.',
    prize: '$50 Donation in your name',
    endDate: Date.now() + 86400000 * 14
  }
];

export const MOCK_MESSAGES: Message[] = [
  {
    id: 'msg1',
    sender: 'Admin',
    content: 'Welcome to EcoQuest! Start by completing your first task today.',
    timestamp: Date.now() - 100000,
    type: 'MANUAL',
    isRead: false
  }
];

export const MOCK_PROGRAMS: Program[] = [
  {
    id: 'p1',
    title: 'Youth Climate Ambassador Program',
    provider: 'Dept of Environment',
    description: 'A 6-month leadership program for students to represent their schools in national climate policy discussions.',
    requirements: 'Must have completed 50 tasks and maintained active status.',
    minPoints: 1500,
    deadline: Date.now() + 86400000 * 30, // 30 days
    status: 'OPEN',
    applicationStatus: 'NONE'
  },
  {
    id: 'p2',
    title: 'Green Innovation Grant',
    provider: 'National Science Foundation',
    description: 'Funding up to $500 for student-led campus sustainability projects.',
    requirements: 'Submit a detailed project proposal. Open to all active students.',
    minPoints: 500,
    deadline: Date.now() + 86400000 * 15,
    status: 'OPEN',
    applicationStatus: 'NONE'
  },
  {
    id: 'p3',
    title: 'Summer Park Ranger Internship',
    provider: 'National Park Service',
    description: 'Paid summer internship for high school seniors to work in national parks.',
    requirements: 'Outdoor experience preferred. High completion of Conservation tasks.',
    minPoints: 2000,
    deadline: Date.now() - 86400000 * 2,
    status: 'CLOSED',
    applicationStatus: 'NONE'
  }
];

export const MOCK_RESOURCES: LearningResource[] = [
  {
    id: 'res1',
    title: 'Understanding the Carbon Cycle',
    type: 'ARTICLE',
    category: 'Science',
    description: 'A comprehensive guide to how carbon moves through our atmosphere and ecosystem.',
    url: '#',
    thumbnailUrl: 'https://picsum.photos/300/200?random=1',
    duration: '5 min read'
  },
  {
    id: 'res2',
    title: 'How to Start Composting',
    type: 'VIDEO',
    category: 'Lifestyle',
    description: 'Step-by-step video tutorial on setting up a compost bin in your backyard.',
    url: '#',
    thumbnailUrl: 'https://picsum.photos/300/200?random=2',
    duration: '12:30'
  },
  {
    id: 'res3',
    title: 'Renewable Energy Technologies',
    type: 'COURSE',
    category: 'Technology',
    description: 'Mini-course covering solar, wind, and hydro power basics.',
    url: '#',
    thumbnailUrl: 'https://picsum.photos/300/200?random=3',
    duration: '4 Modules'
  }
];

export const MOCK_FAQS: FaqItem[] = [
  {
    id: 'f1',
    question: 'How are my points calculated?',
    answer: 'Points are based on task difficulty. Easy tasks earn 50 pts, Medium 150 pts, and Hard 300 pts. AI verification quality scores can also affect the final amount.',
    category: 'Points & Rewards'
  },
  {
    id: 'f2',
    question: 'How do I verify a task?',
    answer: 'Go to the task details page, ensure you are at the correct location (if required), and upload a photo of your work. Our AI will analyze it instantly.',
    category: 'Tasks'
  },
  {
    id: 'f3',
    question: 'Who can see my profile?',
    answer: 'Your profile is visible to Admins and Educators. On the leaderboard, only your name and school are shown to other students.',
    category: 'Account'
  }
];