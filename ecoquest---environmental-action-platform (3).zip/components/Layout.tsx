import React, { useState } from 'react';
import { useApp } from '../AppContext';
import { Menu, X, Leaf, LogOut, LayoutDashboard, Map, BrainCircuit, Trophy, ShoppingBag, Settings, Briefcase, BookOpen, HelpCircle } from 'lucide-react';
import { UserRole } from '../types';

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, logout, navigate, currentView } = useApp();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleNav = (view: string) => {
    navigate(view);
    setIsMenuOpen(false);
  };

  const NavItem: React.FC<{ view: string; icon: React.ReactNode; label: string }> = ({ view, icon, label }) => (
    <button 
      onClick={() => handleNav(view)} 
      className={`flex items-center space-x-1 hover:text-forest-100 transition ${currentView === view ? 'text-forest-100 font-bold' : ''}`}
    >
      {icon} <span>{label}</span>
    </button>
  );

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="bg-forest-700 text-white sticky top-0 z-50 shadow-md">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-2 cursor-pointer" onClick={() => handleNav('landing')}>
            <Leaf className="h-8 w-8 text-forest-100" />
            <span className="text-xl font-bold font-display tracking-tight">EcoQuest</span>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden xl:flex items-center space-x-5">
            {!user ? (
              <>
                <button onClick={() => handleNav('landing')} className="hover:text-forest-100 transition">Home</button>
                <button onClick={() => handleNav('login')} className="px-4 py-2 bg-white text-forest-700 rounded-lg font-semibold hover:bg-gray-100 transition">Login / Register</button>
              </>
            ) : (
              <>
                <NavItem view="dashboard" icon={<LayoutDashboard size={18} />} label="Dashboard" />

                {user.role === UserRole.STUDENT && (
                  <>
                    <NavItem view="tasks" icon={<Map size={18} />} label="Tasks" />
                    <NavItem view="learn" icon={<BookOpen size={18} />} label="Learn" />
                    <NavItem view="quizzes" icon={<BrainCircuit size={18} />} label="Quizzes" />
                    <NavItem view="programs" icon={<Briefcase size={18} />} label="Programs" />
                    <NavItem view="achievements" icon={<Trophy size={18} />} label="Badges" />
                    <NavItem view="rewards" icon={<ShoppingBag size={18} />} label="Rewards" />
                  </>
                )}
                
                {(user.role === UserRole.ADMIN || user.role === UserRole.EDUCATOR) && (
                   <button onClick={() => handleNav('admin')} className={`flex items-center space-x-1 hover:text-forest-100 ${currentView === 'admin' ? 'text-forest-100 font-bold' : ''}`}>
                   <span>Admin Console</span>
                 </button>
                )}

                <div className="flex items-center space-x-3 ml-4 pl-4 border-l border-forest-500">
                  <div className="text-right hidden lg:block">
                    <p className="text-sm font-semibold">{user.name}</p>
                    <p className="text-xs text-forest-100">
                        {user.role === UserRole.ADMIN ? 'Administrator' : `${user.points} pts`}
                    </p>
                  </div>
                  <button onClick={() => handleNav('settings')} className="p-2 hover:bg-forest-900 rounded-full transition" title="Settings">
                    <Settings size={18} />
                  </button>
                  <button onClick={logout} className="p-2 hover:bg-forest-900 rounded-full transition" title="Logout">
                    <LogOut size={18} />
                  </button>
                </div>
              </>
            )}
          </nav>

          {/* Mobile Menu Toggle */}
          <button className="xl:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>

        {/* Mobile Nav */}
        {isMenuOpen && (
          <div className="xl:hidden bg-forest-900 px-4 py-4 space-y-4">
            {!user ? (
               <button onClick={() => handleNav('login')} className="block w-full text-left py-2 text-white">Login / Register</button>
            ) : (
              <>
                <button onClick={() => handleNav('dashboard')} className="block w-full text-left py-2 text-white border-b border-forest-700">Dashboard</button>
                
                {user.role === UserRole.STUDENT && (
                  <>
                    <button onClick={() => handleNav('tasks')} className="block w-full text-left py-2 text-white border-b border-forest-700">Tasks</button>
                    <button onClick={() => handleNav('learn')} className="block w-full text-left py-2 text-white border-b border-forest-700">Learn</button>
                    <button onClick={() => handleNav('programs')} className="block w-full text-left py-2 text-white border-b border-forest-700">Gov. Programs</button>
                    <button onClick={() => handleNav('achievements')} className="block w-full text-left py-2 text-white border-b border-forest-700">Achievements</button>
                    <button onClick={() => handleNav('quizzes')} className="block w-full text-left py-2 text-white border-b border-forest-700">Quizzes</button>
                    <button onClick={() => handleNav('rewards')} className="block w-full text-left py-2 text-white border-b border-forest-700">Rewards</button>
                    <button onClick={() => handleNav('leaderboard')} className="block w-full text-left py-2 text-white border-b border-forest-700">Leaderboard</button>
                  </>
                )}

                {(user.role === UserRole.ADMIN || user.role === UserRole.EDUCATOR) && (
                   <button onClick={() => handleNav('admin')} className="block w-full text-left py-2 text-white border-b border-forest-700">Admin Console</button>
                )}
                
                <button onClick={() => handleNav('settings')} className="block w-full text-left py-2 text-white border-b border-forest-700">Settings</button>
                <button onClick={() => handleNav('support')} className="block w-full text-left py-2 text-white border-b border-forest-700">Help & Support</button>
                <button onClick={logout} className="block w-full text-left py-2 text-red-300">Logout</button>
              </>
            )}
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-grow container mx-auto px-4 py-6">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-gray-400 py-8">
        <div className="container mx-auto px-4 text-center">
          <div className="flex justify-center space-x-4 mb-4">
             <Leaf className="text-forest-500" />
          </div>
          <p>© 2024 EcoQuest. Empowering Environmental Action.</p>
          <div className="mt-4 space-x-4 text-sm flex justify-center flex-wrap gap-4">
            <button onClick={() => handleNav('support')} className="hover:text-white">Help & Support</button>
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Service</a>
            <a href="#" className="hover:text-white">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
};