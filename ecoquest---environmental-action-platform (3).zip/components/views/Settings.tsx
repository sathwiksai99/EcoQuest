import React from 'react';
import { useApp } from '../../AppContext';
import { UserRole } from '../../types';
import { LogOut, Trash2, User as UserIcon, Mail, Shield } from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const { user, logout, deleteAccount } = useApp();

  if (!user) return null;

  const handleDelete = () => {
    if (window.confirm("Are you sure you want to delete your account? This action cannot be undone and you will lose all progress and points.")) {
      deleteAccount();
    }
  };

  return (
    <div className="max-w-2xl mx-auto py-10 space-y-8">
      <h1 className="text-3xl font-bold font-display text-gray-900">Account Settings</h1>

      {/* Profile Card */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="bg-forest-600 h-24"></div>
        <div className="px-8 pb-8">
          <div className="relative -mt-12 mb-6">
            <div className="w-24 h-24 bg-white rounded-full p-2 shadow-md">
              <div className="w-full h-full bg-gray-200 rounded-full flex items-center justify-center text-gray-500">
                <UserIcon size={40} />
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Full Name</label>
              <div className="text-lg font-bold text-gray-900">{user.name}</div>
            </div>
            
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Email Address</label>
              <div className="flex items-center gap-2 text-gray-700">
                <Mail size={16} /> {user.email}
              </div>
            </div>

            <div>
               <label className="text-xs font-bold text-gray-500 uppercase tracking-wide">Account Type</label>
               <div className="flex items-center gap-2 mt-1">
                 <span className={`px-3 py-1 rounded-full text-xs font-bold ${user.role === UserRole.ADMIN ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'}`}>
                    {user.role}
                 </span>
               </div>
            </div>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 space-y-6">
        <h3 className="text-lg font-bold text-gray-900 border-b border-gray-100 pb-4">Account Actions</h3>
        
        <div className="flex items-center justify-between">
          <div>
            <div className="font-bold text-gray-700">Sign Out</div>
            <div className="text-sm text-gray-500">Securely log out of your session on this device.</div>
          </div>
          <button onClick={logout} className="px-4 py-2 border border-gray-300 rounded-lg font-bold text-gray-700 hover:bg-gray-50 flex items-center gap-2">
            <LogOut size={18} /> Sign Out
          </button>
        </div>

        <div className="pt-6 border-t border-gray-100 flex items-center justify-between">
          <div>
            <div className="font-bold text-red-600">Delete Account</div>
            <div className="text-sm text-gray-500">Permanently remove your profile and all data.</div>
          </div>
          <button onClick={handleDelete} className="px-4 py-2 bg-red-50 border border-red-200 rounded-lg font-bold text-red-600 hover:bg-red-100 flex items-center gap-2">
            <Trash2 size={18} /> Delete Account
          </button>
        </div>
      </div>
    </div>
  );
};