import React from 'react';
import { useApp } from '../../AppContext';
import { ArrowRight, Globe, Award, CheckCircle } from 'lucide-react';

export const LandingPage: React.FC = () => {
  const { navigate } = useApp();

  return (
    <div className="space-y-16 py-8">
      {/* Hero */}
      <section className="text-center space-y-6 max-w-4xl mx-auto">
        <h1 className="text-5xl md:text-6xl font-extrabold text-forest-900 tracking-tight font-display">
          Turn Your <span className="text-forest-500">Eco-Action</span> into Real Impact
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Join thousands of students and educators making a difference. Complete environmental tasks, earn rewards, and track your contribution to a greener planet.
        </p>
        <div className="flex justify-center gap-4">
          <button 
            onClick={() => navigate('register-student')}
            className="bg-forest-500 hover:bg-forest-600 text-white px-8 py-3 rounded-full font-bold text-lg shadow-lg hover:shadow-xl transition flex items-center gap-2"
          >
            Get Started <ArrowRight size={20} />
          </button>
          <button 
             onClick={() => navigate('register-educator')}
            className="bg-white border-2 border-forest-500 text-forest-700 px-8 py-3 rounded-full font-bold text-lg hover:bg-gray-50 transition"
          >
            I'm an Educator
          </button>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
        <div>
          <div className="text-4xl font-bold text-forest-500 mb-2">10k+</div>
          <div className="text-gray-600">Active Students</div>
        </div>
        <div>
          <div className="text-4xl font-bold text-sky-500 mb-2">50k+</div>
          <div className="text-gray-600">Trees Planted</div>
        </div>
        <div>
          <div className="text-4xl font-bold text-gold-500 mb-2">1M+</div>
          <div className="text-gray-600">Green Points Earned</div>
        </div>
      </section>

      {/* Features */}
      <section className="grid md:grid-cols-3 gap-8">
        <div className="bg-sky-50 p-6 rounded-xl hover:-translate-y-1 transition duration-300">
          <Globe className="w-12 h-12 text-sky-600 mb-4" />
          <h3 className="text-xl font-bold text-gray-900 mb-2">Real World Impact</h3>
          <p className="text-gray-600">
            Tasks are verified with GPS and AI-powered photo recognition to ensure genuine environmental contribution.
          </p>
        </div>
        <div className="bg-forest-50 p-6 rounded-xl hover:-translate-y-1 transition duration-300">
          <CheckCircle className="w-12 h-12 text-forest-600 mb-4" />
          <h3 className="text-xl font-bold text-gray-900 mb-2">Track Progress</h3>
          <p className="text-gray-600">
            Visualize your carbon offset and learning journey with interactive dashboards and analytics.
          </p>
        </div>
        <div className="bg-yellow-50 p-6 rounded-xl hover:-translate-y-1 transition duration-300">
          <Award className="w-12 h-12 text-gold-500 mb-4" />
          <h3 className="text-xl font-bold text-gray-900 mb-2">Earn Rewards</h3>
          <p className="text-gray-600">
            Redeem your Green Points for sustainable products, educational courses, or donations.
          </p>
        </div>
      </section>
    </div>
  );
};