import React, { useState } from 'react';
import { useApp } from '../../AppContext';
import { Search, BookOpen, PlayCircle, GraduationCap, Bookmark, ArrowLeft, CheckCircle, Clock } from 'lucide-react';
import { MOCK_RESOURCES } from '../../constants';
import { LearningResource } from '../../types';

export const LearnPage: React.FC = () => {
  const [filter, setFilter] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedResource, setSelectedResource] = useState<LearningResource | null>(null);

  const filteredResources = MOCK_RESOURCES.filter(res => {
     const matchesFilter = filter === 'All' || res.category === filter || res.type === filter;
     const matchesSearch = res.title.toLowerCase().includes(searchTerm.toLowerCase());
     return matchesFilter && matchesSearch;
  });

  const categories = ['All', 'Science', 'Lifestyle', 'Technology'];

  // --- DETAIL VIEW ---
  if (selectedResource) {
      return <ResourceViewer resource={selectedResource} onBack={() => setSelectedResource(null)} />;
  }

  // --- LIST VIEW ---
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-end gap-4">
        <div>
          <h1 className="text-3xl font-bold font-display text-gray-900">Learning Library</h1>
          <p className="text-gray-500">Curated content to deepen your environmental knowledge.</p>
        </div>
        
        <div className="w-full md:w-auto flex flex-col sm:flex-row gap-3">
            <div className="relative">
                <Search className="absolute left-3 top-3 text-gray-400" size={18} />
                <input 
                    type="text" 
                    placeholder="Search topics..." 
                    className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-forest-500 focus:outline-none w-full"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            <select 
               className="px-4 py-2 border border-gray-300 rounded-lg bg-white focus:ring-2 focus:ring-forest-500 outline-none"
               value={filter}
               onChange={(e) => setFilter(e.target.value)}
            >
                {categories.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredResources.map(res => (
          <div 
            key={res.id} 
            onClick={() => setSelectedResource(res)}
            className="group bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition cursor-pointer flex flex-col h-full"
          >
            <div className="h-48 overflow-hidden relative shrink-0">
              <img src={res.thumbnailUrl} alt={res.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
              <div className="absolute top-3 right-3 bg-black/60 backdrop-blur text-white px-2 py-1 rounded text-xs font-bold flex items-center gap-1">
                 {res.type === 'VIDEO' ? <PlayCircle size={12} /> : res.type === 'COURSE' ? <GraduationCap size={12} /> : <BookOpen size={12} />}
                 {res.type}
              </div>
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition duration-300 bg-black/20">
                  <span className="bg-white text-forest-700 px-4 py-2 rounded-full font-bold text-sm shadow-lg transform scale-95 group-hover:scale-100 transition">
                      {res.type === 'VIDEO' ? 'Watch Now' : 'Read Now'}
                  </span>
              </div>
            </div>
            <div className="p-5 flex flex-col flex-grow">
               <div className="flex justify-between items-center mb-2">
                 <span className="text-xs font-bold text-forest-600 uppercase tracking-wide">{res.category}</span>
                 <span className="text-xs text-gray-400 flex items-center gap-1"><Clock size={12}/> {res.duration}</span>
               </div>
               <h3 className="font-bold text-gray-900 mb-2 leading-tight group-hover:text-forest-600 transition">{res.title}</h3>
               <p className="text-sm text-gray-500 line-clamp-2 mb-4">{res.description}</p>
               
               <div className="mt-auto flex justify-between items-center pt-4 border-t border-gray-100">
                  <span className="text-forest-600 text-sm font-bold hover:underline">
                      {res.type === 'VIDEO' ? 'Play Video' : res.type === 'COURSE' ? 'Start Course' : 'Read Article'}
                  </span>
                  <button className="text-gray-400 hover:text-gold-500 transition"><Bookmark size={18} /></button>
               </div>
            </div>
          </div>
        ))}
        {filteredResources.length === 0 && (
            <div className="col-span-full text-center py-20 text-gray-400">
                No resources found matching your search.
            </div>
        )}
      </div>
    </div>
  );
};

const ResourceViewer: React.FC<{ resource: LearningResource; onBack: () => void }> = ({ resource, onBack }) => {
    const [isComplete, setIsComplete] = useState(false);

    return (
        <div className="max-w-4xl mx-auto space-y-6 pb-20">
            <button onClick={onBack} className="flex items-center text-gray-500 hover:text-forest-600 mb-4 transition font-medium">
                <ArrowLeft size={20} className="mr-2" /> Back to Library
            </button>

            <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
                {/* Header */}
                <div className="p-8 border-b border-gray-100 bg-gray-50">
                    <div className="flex items-center gap-3 mb-4 text-sm">
                        <span className="bg-forest-100 text-forest-700 px-3 py-1 rounded-full font-bold uppercase text-xs">{resource.category}</span>
                        <span className="flex items-center gap-1 text-gray-500 font-medium"><Clock size={14}/> {resource.duration}</span>
                        <span className="flex items-center gap-1 text-gray-500 font-medium">
                            {resource.type === 'VIDEO' ? <PlayCircle size={14} /> : resource.type === 'COURSE' ? <GraduationCap size={14} /> : <BookOpen size={14} />} 
                            {resource.type}
                        </span>
                    </div>
                    <h1 className="text-3xl md:text-4xl font-bold font-display text-gray-900 mb-4">{resource.title}</h1>
                    <p className="text-gray-600 text-lg leading-relaxed">{resource.description}</p>
                </div>

                {/* Content Body */}
                <div className="p-0 bg-white min-h-[400px]">
                    {resource.type === 'VIDEO' && (
                        <div className="aspect-video w-full bg-black flex items-center justify-center relative group">
                            {/* In a real app, this would be a YouTube/Vimeo embed */}
                            <img src={resource.thumbnailUrl} className="w-full h-full object-cover opacity-50" alt="Video cover"/>
                            <div className="absolute inset-0 flex items-center justify-center">
                                <button className="bg-white/20 backdrop-blur-sm border-2 border-white text-white w-20 h-20 rounded-full flex items-center justify-center hover:scale-110 transition duration-300">
                                    <PlayCircle size={40} fill="currentColor" className="text-white" />
                                </button>
                            </div>
                            <div className="absolute bottom-4 left-4 text-white text-sm font-medium bg-black/50 px-3 py-1 rounded">
                                Simulated Video Player
                            </div>
                        </div>
                    )}

                    {resource.type === 'ARTICLE' && (
                        <div className="p-8 md:p-12 prose prose-forest max-w-none text-gray-700">
                            <p className="lead text-xl">
                                Welcome to this comprehensive guide on {resource.title}. In this article, we will explore the fundamental concepts and practical applications relevant to {resource.category}.
                            </p>
                            <h3 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Introduction</h3>
                            <p className="mb-4">
                                Understanding our environment is the first step towards preserving it. Whether we are discussing carbon cycles, waste management, or renewable energy, the core principles remain rooted in sustainability and balance.
                            </p>
                            <div className="my-8">
                                <img src={resource.thumbnailUrl} className="w-full h-64 object-cover rounded-xl" alt="Article Visual" />
                                <p className="text-sm text-gray-500 mt-2 italic text-center">Visual representation of the topic</p>
                            </div>
                            <h3 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Key Concepts</h3>
                            <p className="mb-4">
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
                            </p>
                            <ul className="list-disc pl-6 space-y-2 mb-6">
                                <li>Impact of human activity on local ecosystems.</li>
                                <li>Strategies for mitigation and adaptation.</li>
                                <li>The role of technology in monitoring environmental health.</li>
                            </ul>
                            <h3 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Conclusion</h3>
                            <p>
                                By integrating these practices into daily life, we can collectively reduce our footprint. Education is the catalyst for change.
                            </p>
                        </div>
                    )}

                    {resource.type === 'COURSE' && (
                        <div className="p-8">
                             <h3 className="text-xl font-bold text-gray-900 mb-6 border-b pb-2">Course Curriculum</h3>
                             <div className="space-y-4">
                                 {[1, 2, 3, 4].map((module) => (
                                     <div key={module} className="border border-gray-200 rounded-lg p-4 flex items-center justify-between hover:bg-gray-50 transition cursor-pointer">
                                         <div className="flex items-center gap-4">
                                             <div className="w-8 h-8 rounded-full bg-forest-100 text-forest-700 flex items-center justify-center font-bold">
                                                 {module}
                                             </div>
                                             <div>
                                                 <h4 className="font-bold text-gray-800">Module {module}: Fundamentals of {resource.category}</h4>
                                                 <p className="text-xs text-gray-500">Video Lesson • 15 mins</p>
                                             </div>
                                         </div>
                                         <PlayCircle size={20} className="text-gray-400" />
                                     </div>
                                 ))}
                             </div>
                        </div>
                    )}
                </div>

                {/* Footer / Actions */}
                <div className="bg-gray-50 p-6 border-t border-gray-100 flex justify-between items-center">
                     <p className="text-sm text-gray-500 italic">
                         {isComplete ? "Completed on " + new Date().toLocaleDateString() : "Progress is saved automatically."}
                     </p>
                     <button 
                        onClick={() => setIsComplete(!isComplete)}
                        className={`px-6 py-3 rounded-xl font-bold transition flex items-center gap-2 ${isComplete ? 'bg-green-100 text-green-700' : 'bg-forest-600 text-white hover:bg-forest-700 shadow-md'}`}
                     >
                         {isComplete ? <><CheckCircle size={20} /> Completed</> : "Mark as Complete"}
                     </button>
                </div>
            </div>
        </div>
    );
};
