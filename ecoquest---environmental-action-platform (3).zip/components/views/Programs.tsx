import React, { useState } from 'react';
import { useApp } from '../../AppContext';
import { Briefcase, Calendar, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { Program } from '../../types';

export const ProgramsPage: React.FC = () => {
  const { user, programs, applyToProgram } = useApp();

  const handleApply = (program: Program) => {
    if (!user) return;
    if (user.points < program.minPoints) {
      alert(`You need ${program.minPoints} points to apply for this program.`);
      return;
    }
    if (confirm(`Apply for ${program.title}? This will share your profile with ${program.provider}.`)) {
      applyToProgram(program.id);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-8 text-white shadow-lg">
        <h1 className="text-3xl font-bold font-display mb-2">Government & NGO Initiatives</h1>
        <p className="opacity-90 max-w-2xl">
          Leverage your green credentials to access exclusive internships, grants, and leadership programs provided by our partners.
        </p>
      </div>

      <div className="grid gap-6">
        {programs.map(program => {
          const isEligible = (user?.points || 0) >= program.minPoints;
          const isApplied = program.applicationStatus && program.applicationStatus !== 'NONE';
          const isClosed = program.status === 'CLOSED';

          return (
            <div key={program.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 flex flex-col md:flex-row gap-6 hover:shadow-md transition">
              <div className="flex-shrink-0">
                <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center">
                  <Briefcase size={32} />
                </div>
              </div>
              
              <div className="flex-grow">
                <div className="flex flex-col md:flex-row md:justify-between md:items-start mb-2">
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">{program.title}</h3>
                    <p className="text-blue-600 font-medium">{program.provider}</p>
                  </div>
                  <div className="mt-2 md:mt-0">
                     {isApplied ? (
                       <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${program.applicationStatus === 'ACCEPTED' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                         {program.applicationStatus}
                       </span>
                     ) : isClosed ? (
                       <span className="bg-gray-100 text-gray-500 px-3 py-1 rounded-full text-xs font-bold uppercase">Applications Closed</span>
                     ) : (
                       <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-xs font-bold uppercase">Applications Open</span>
                     )}
                  </div>
                </div>

                <p className="text-gray-600 mb-4">{program.description}</p>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm text-gray-500 mb-6">
                  <div className="flex items-center gap-2">
                    <CheckCircle size={16} className="text-forest-500" />
                    <span>Eligibility: <span className={isEligible ? 'text-green-600 font-bold' : 'text-red-500 font-bold'}>{program.minPoints} Points</span></span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar size={16} className="text-gray-400" />
                    <span>Deadline: {new Date(program.deadline).toLocaleDateString()}</span>
                  </div>
                </div>

                <div className="bg-gray-50 p-3 rounded-lg text-sm text-gray-700 mb-4">
                  <strong>Requirements:</strong> {program.requirements}
                </div>

                {!isApplied && !isClosed && (
                  <button 
                    onClick={() => handleApply(program)}
                    disabled={!isEligible}
                    className={`px-6 py-2 rounded-lg font-bold transition flex items-center gap-2 ${
                      isEligible 
                      ? 'bg-blue-600 text-white hover:bg-blue-700' 
                      : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    }`}
                  >
                    {!isEligible && <AlertCircle size={16} />}
                    {isEligible ? 'Apply Now' : 'Points Requirement Not Met'}
                  </button>
                )}
                
                {isApplied && (
                   <div className="flex items-center gap-2 text-blue-600 font-bold bg-blue-50 px-4 py-2 rounded-lg w-fit">
                      <Clock size={18} /> Application under review
                   </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};