import React from 'react';
import { useApp } from '../../AppContext';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Leaf, ArrowUpRight, Zap, Loader2, Mail, BrainCircuit } from 'lucide-react';
import { UserRole } from '../../types';
import { AdminPage } from './Admin';

export const DashboardPage: React.FC = () => {
  const { user } = useApp();

  // Prevent white page by showing a loader while user data hydrates
  if (!user) {
      return (
          <div className="min-h-[50vh] flex items-center justify-center">
              <Loader2 className="animate-spin text-forest-600" size={32} />
          </div>
      );
  }

  // Route logic: Show separate dashboards based on role
  if (user.role === UserRole.ADMIN || user.role === UserRole.EDUCATOR) {
    // Admins are directed to the main Admin Page which acts as their dashboard
    return <AdminPage />;
  }

  return <StudentDashboard />;
};

// --- STUDENT DASHBOARD ---
const StudentDashboard: React.FC = () => {
  const { user, tasks, messages, navigate, markMessageRead } = useApp();
  if (!user) return null;

  const data = [
    { name: 'Mon', points: 0 },
    { name: 'Tue', points: 150 },
    { name: 'Wed', points: 150 },
    { name: 'Thu', points: 450 },
    { name: 'Fri', points: 500 },
    { name: 'Sat', points: 600 },
    { name: 'Sun', points: user.points },
  ];

  const unreadMessages = messages.filter(m => !m.isRead);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-end">
        <div>
           <h1 className="text-3xl font-bold text-gray-900 font-display">Hello, {user.name} 👋</h1>
           <p className="text-gray-500">Track your environmental impact.</p>
        </div>
        <button onClick={() => navigate('tasks')} className="hidden md:flex items-center text-forest-600 font-semibold hover:text-forest-800">
            Find new tasks <ArrowUpRight size={18} className="ml-1" />
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-forest-500 to-forest-700 rounded-2xl p-6 text-white shadow-lg">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-forest-100 font-medium mb-1">Total Green Points</p>
              <h3 className="text-4xl font-bold">{user.points}</h3>
            </div>
            <div className="p-2 bg-white/20 rounded-lg">
              <Leaf className="text-white" />
            </div>
          </div>
          <div className="mt-4 text-sm text-forest-100">
            Keep completing tasks to grow your impact!
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
             <div onClick={() => navigate('quizzes')} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 cursor-pointer hover:shadow-md transition">
                 <div className="p-2 bg-purple-100 text-purple-600 rounded-lg w-fit mb-3">
                     <BrainCircuit size={20} />
                 </div>
                 <h4 className="font-bold text-gray-900">Quick Quiz</h4>
                 <p className="text-xs text-gray-500">Earn points learning</p>
             </div>
             
             <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 flex flex-col justify-center">
                 <h4 className="font-bold text-gray-900 text-sm mb-1">Gov. Program</h4>
                 <button className="bg-blue-600 text-white px-3 py-1.5 rounded-lg text-xs font-semibold hover:bg-blue-700 w-fit">Apply Now</button>
             </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Impact Over Time</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorPoints" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#22c55e" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#9ca3af'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#9ca3af'}} />
                <Tooltip />
                <Area type="monotone" dataKey="points" stroke="#22c55e" fillOpacity={1} fill="url(#colorPoints)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Sidebar Widgets */}
        <div className="space-y-6">
           {/* Inbox Widget */}
           <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
               <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center justify-between">
                   Inbox 
                   {unreadMessages.length > 0 && <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">{unreadMessages.length}</span>}
               </h3>
               <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
                   {messages.length === 0 && <p className="text-sm text-gray-400">No messages.</p>}
                   {messages.map(msg => (
                       <div key={msg.id} className={`p-3 rounded-lg border text-sm transition ${msg.isRead ? 'bg-gray-50 border-gray-100 text-gray-500' : 'bg-white border-blue-100 shadow-sm border-l-4 border-l-blue-500'}`} onClick={() => markMessageRead(msg.id)}>
                           <div className="flex justify-between mb-1">
                               <span className="font-bold text-gray-800">{msg.sender}</span>
                               <span className="text-xs text-gray-400">{new Date(msg.timestamp).toLocaleDateString()}</span>
                           </div>
                           <p>{msg.content}</p>
                       </div>
                   ))}
               </div>
           </div>

           {/* Recommended Tasks */}
           <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Recommended</h3>
              <div className="space-y-4">
                {tasks.slice(0,3).map(task => (
                    <div key={task.id} className="p-3 bg-gray-50 rounded-lg hover:bg-forest-50 transition cursor-pointer" onClick={() => navigate('tasks')}>
                        <div className="flex justify-between items-start">
                            <span className="text-xs font-bold text-forest-600 uppercase tracking-wide">{task.difficulty}</span>
                            <div className="flex gap-1">
                              {task.isPriority && <Zap size={14} className="text-yellow-500" fill="currentColor" />}
                              <span className="text-xs font-bold bg-white px-2 py-1 rounded border border-gray-200">{task.points} pts</span>
                            </div>
                        </div>
                        <h4 className="font-bold text-gray-800 mt-1">{task.title}</h4>
                    </div>
                ))}
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};