import React from 'react';
import { useApp } from '../../AppContext';
import { MOCK_REWARDS } from '../../constants';
import { ShoppingBag, Lock } from 'lucide-react';

export const RewardsPage: React.FC = () => {
  const { user, addPoints } = useApp();

  const handleRedeem = (cost: number) => {
    // In a real app, this would deduct points.
    // Since our context mock only has 'addPoints', let's simulate a purchase by subtracting visually or showing a success.
    if (!user || user.points < cost) return;
    addPoints(-cost); 
    alert("Reward Redeemed! Check your email for details.");
  };

  return (
    <div className="space-y-6">
       <div className="bg-gradient-to-r from-gold-400 to-gold-500 rounded-2xl p-8 text-white flex justify-between items-center shadow-lg">
           <div>
               <h1 className="text-3xl font-bold font-display">Rewards Marketplace</h1>
               <p className="opacity-90">Exchange your hard-earned Green Points for real value.</p>
           </div>
           <div className="text-right">
               <p className="text-sm font-bold opacity-75 uppercase tracking-wider">Your Balance</p>
               <p className="text-5xl font-extrabold">{user?.points || 0}</p>
           </div>
       </div>

       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
           {MOCK_REWARDS.map(reward => {
               const canAfford = (user?.points || 0) >= reward.cost;
               return (
                   <div key={reward.id} className="bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col overflow-hidden hover:shadow-md transition">
                       <div className="h-32 bg-gray-100 flex items-center justify-center text-gray-300">
                           {/* Placeholder for reward image */}
                           <ShoppingBag size={48} />
                       </div>
                       <div className="p-6 flex flex-col flex-grow">
                           <div className="flex justify-between items-start mb-2">
                               <span className="text-xs font-bold text-gray-500 bg-gray-100 px-2 py-1 rounded">{reward.type}</span>
                               <span className="font-bold text-gold-500">{reward.cost} PTS</span>
                           </div>
                           <h3 className="font-bold text-gray-900 mb-2">{reward.title}</h3>
                           <p className="text-sm text-gray-500 mb-6">{reward.description}</p>
                           
                           <button 
                            onClick={() => handleRedeem(reward.cost)}
                            disabled={!canAfford}
                            className={`mt-auto w-full py-2 rounded-lg font-bold flex justify-center items-center gap-2 ${canAfford ? 'bg-forest-600 text-white hover:bg-forest-700' : 'bg-gray-100 text-gray-400 cursor-not-allowed'}`}
                           >
                               {canAfford ? 'Redeem' : <><Lock size={14} /> Locked</>}
                           </button>
                       </div>
                   </div>
               );
           })}
       </div>
    </div>
  );
};