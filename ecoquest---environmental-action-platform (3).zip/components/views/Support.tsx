import React, { useState } from 'react';
import { MOCK_FAQS } from '../../constants';
import { Mail, MessageCircle, ChevronDown, ChevronUp, Search, Send } from 'lucide-react';

export const SupportPage: React.FC = () => {
  const [openFaq, setOpenFaq] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  
  const filteredFaqs = MOCK_FAQS.filter(f => 
      f.question.toLowerCase().includes(search.toLowerCase()) || 
      f.answer.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-4xl mx-auto space-y-10">
       <div className="text-center space-y-4">
           <h1 className="text-3xl font-bold font-display text-gray-900">How can we help?</h1>
           <div className="relative max-w-lg mx-auto">
               <Search className="absolute left-3 top-3 text-gray-400" size={20} />
               <input 
                 className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-full focus:ring-2 focus:ring-forest-500 outline-none shadow-sm"
                 placeholder="Search for answers..."
                 value={search}
                 onChange={(e) => setSearch(e.target.value)}
               />
           </div>
       </div>

       <div className="grid md:grid-cols-3 gap-8">
           <div className="md:col-span-2 space-y-6">
               <h2 className="text-xl font-bold text-gray-900">Frequently Asked Questions</h2>
               <div className="space-y-4">
                   {filteredFaqs.map(faq => (
                       <div key={faq.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden">
                           <button 
                             onClick={() => setOpenFaq(openFaq === faq.id ? null : faq.id)}
                             className="w-full flex justify-between items-center p-4 text-left hover:bg-gray-50 transition"
                           >
                               <span className="font-bold text-gray-800">{faq.question}</span>
                               {openFaq === faq.id ? <ChevronUp size={18} className="text-gray-400"/> : <ChevronDown size={18} className="text-gray-400"/>}
                           </button>
                           {openFaq === faq.id && (
                               <div className="p-4 pt-0 text-gray-600 text-sm border-t border-gray-100 bg-gray-50/50">
                                   {faq.answer}
                               </div>
                           )}
                       </div>
                   ))}
               </div>
           </div>

           <div className="space-y-6">
               <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                   <h3 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
                       <Mail size={18} className="text-forest-500" /> Contact Support
                   </h3>
                   <form className="space-y-3">
                       <input className="w-full px-3 py-2 border rounded-lg text-sm" placeholder="Your Name" />
                       <input className="w-full px-3 py-2 border rounded-lg text-sm" placeholder="Email Address" />
                       <textarea className="w-full px-3 py-2 border rounded-lg text-sm h-24" placeholder="Describe your issue..." />
                       <button className="w-full bg-forest-600 text-white font-bold py-2 rounded-lg hover:bg-forest-700 flex justify-center items-center gap-2">
                           <Send size={16} /> Send Message
                       </button>
                   </form>
               </div>
               
               <div className="bg-sky-50 p-6 rounded-2xl border border-sky-100 text-center">
                   <MessageCircle size={32} className="text-sky-500 mx-auto mb-2" />
                   <h3 className="font-bold text-gray-900">Live Chat</h3>
                   <p className="text-sm text-gray-600 mb-4">Chat with our support team Mon-Fri, 9am - 5pm EST.</p>
                   <button className="bg-white text-sky-600 border border-sky-200 font-bold py-2 px-6 rounded-full hover:bg-sky-100 transition">
                       Start Chat
                   </button>
               </div>
           </div>
       </div>
    </div>
  );
};