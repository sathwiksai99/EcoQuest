import React, { useState } from 'react';
import { useApp } from '../../AppContext';
import { MapPin, Clock, Filter, Search, Zap } from 'lucide-react';
import { Task } from '../../types';

export const TasksPage: React.FC = () => {
  const { tasks, navigate, viewTask } = useApp();
  const [filter, setFilter] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredTasks = tasks.filter(task => {
    const matchesFilter = filter === 'All' || task.category === filter;
    const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const categories = ['All', ...Array.from(new Set(tasks.map(t => t.category)))];

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
        <h1 className="text-3xl font-bold font-display text-gray-900">Available Tasks</h1>
        
        <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative">
                <Search className="absolute left-3 top-3 text-gray-400" size={18} />
                <input 
                    type="text" 
                    placeholder="Search tasks..." 
                    className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-forest-500 focus:outline-none w-full"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            <div className="flex bg-white border border-gray-300 rounded-lg overflow-hidden">
                {categories.map(cat => (
                    <button
                        key={cat}
                        onClick={() => setFilter(cat)}
                        className={`px-4 py-2 text-sm font-medium transition ${filter === cat ? 'bg-forest-600 text-white' : 'hover:bg-gray-50 text-gray-600'}`}
                    >
                        {cat}
                    </button>
                ))}
            </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredTasks.map(task => (
           <TaskCard key={task.id} task={task} onClick={() => viewTask(task.id)} />
        ))}
      </div>
      
      {filteredTasks.length === 0 && (
          <div className="text-center py-20 text-gray-500">
              No tasks found matching your criteria.
          </div>
      )}
    </div>
  );
};

const TaskCard: React.FC<{ task: Task; onClick: () => void }> = ({ task, onClick }) => {
    return (
        <div className="group bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition cursor-pointer flex flex-col h-full" onClick={onClick}>
            <div className="h-48 overflow-hidden relative">
                <img src={task.imageUrl} alt={task.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
                <div className="absolute top-3 right-3 bg-white/90 backdrop-blur px-2 py-1 rounded text-xs font-bold text-forest-700 shadow-sm flex items-center gap-1">
                    {task.isPriority && <Zap size={10} className="text-yellow-500" fill="currentColor" />}
                    {task.points} PTS
                </div>
            </div>
            <div className="p-5 flex flex-col flex-grow">
                <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-bold text-sky-600 bg-sky-50 px-2 py-1 rounded-full">{task.category}</span>
                    <span className={`text-xs font-bold ${task.difficulty === 'Easy' ? 'text-green-600' : task.difficulty === 'Medium' ? 'text-yellow-600' : 'text-red-600'}`}>
                        {task.difficulty}
                    </span>
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2 leading-tight">{task.title}</h3>
                <p className="text-sm text-gray-500 mb-4 line-clamp-2">{task.description}</p>
                
                <div className="mt-auto flex items-center text-xs text-gray-400 space-x-4">
                     {task.locationRequired && (
                         <div className="flex items-center">
                             <MapPin size={14} className="mr-1" /> GPS Verified
                         </div>
                     )}
                     <div className="flex items-center">
                         <Clock size={14} className="mr-1" /> 30-60m
                     </div>
                </div>
            </div>
        </div>
    )
}