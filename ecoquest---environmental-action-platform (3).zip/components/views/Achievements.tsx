import React from 'react';
import { useApp } from '../../AppContext';
import { MOCK_BADGES } from '../../constants';
import { Lock, Trophy, Star } from 'lucide-react';

export const AchievementsPage: React.FC = () => {
  const { user } = useApp();
  
  const earnedBadges = MOCK_BADGES.filter(b => (user?.points || 0) >= b.requiredPoints);
  const nextBadge = MOCK_BADGES.find(b => (user?.points || 0) < b.requiredPoints);
  
  const progress = nextBadge 
    ? Math.min(100, ((user?.points || 0) / nextBadge.requiredPoints) * 100) 
    : 100;

  return (
    <div className="space-y-8">
       <div className="bg-forest-900 text-white p-8 rounded-2xl relative overflow-hidden">
          <div className="relative z-10">
              <h1 className="text-3xl font-bold font-display mb-2">My Achievements</h1>
              <p className="text-forest-200 mb-6">Track your environmental milestones and badge collection.</p>
              
              <div className="bg-white/10 backdrop-blur rounded-xl p-4 max-w-xl">
                  <div className="flex justify-between text-sm font-bold mb-2">
                      <span>Next Milestone: {nextBadge ? nextBadge.name : 'Max Level Reached!'}</span>
                      <span>{user?.points} / {nextBadge?.requiredPoints || user?.points} PTS</span>
                  </div>
                  <div className="w-full bg-black/20 rounded-full h-3">
                      <div className="bg-gold-500 h-3 rounded-full transition-all duration-1000" style={{width: `${progress}%`}}></div>
                  </div>
              </div>
          </div>
          <Trophy className="absolute right-[-20px] bottom-[-40px] text-white/5" size={200} />
       </div>

       <div>
         <h2 className="text-xl font-bold text-gray-900 mb-6 flex items-center gap-2">
            <Star className="text-gold-500" fill="currentColor" /> Badge Collection
         </h2>
         
         <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
             {MOCK_BADGES.map(badge => {
                 const isUnlocked = (user?.points || 0) >= badge.requiredPoints;
                 return (
                     <div key={badge.id} className={`relative rounded-xl p-6 flex flex-col items-center text-center transition ${isUnlocked ? 'bg-white shadow-sm border border-gold-100' : 'bg-gray-50 border border-gray-200 opacity-70 grayscale'}`}>
                         <div className={`w-16 h-16 rounded-full flex items-center justify-center text-3xl mb-4 ${isUnlocked ? 'bg-gold-50 shadow-inner' : 'bg-gray-200'}`}>
                             {isUnlocked ? badge.icon : <Lock size={24} className="text-gray-400" />}
                         </div>
                         <h3 className="font-bold text-gray-900 mb-1">{badge.name}</h3>
                         <p className="text-xs text-gray-500 mb-3 h-8">{badge.description}</p>
                         
                         {isUnlocked ? (
                             <span className="text-xs font-bold text-green-600 bg-green-50 px-2 py-1 rounded-full">Unlocked</span>
                         ) : (
                             <span className="text-xs font-bold text-gray-400 bg-gray-200 px-2 py-1 rounded-full">{badge.requiredPoints} PTS Required</span>
                         )}
                     </div>
                 );
             })}
         </div>
       </div>
    </div>
  );
};