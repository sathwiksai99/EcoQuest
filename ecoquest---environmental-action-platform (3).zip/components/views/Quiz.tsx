import React, { useState } from 'react';
import { useApp } from '../../AppContext';
import { MOCK_QUIZZES } from '../../constants';
import { Quiz } from '../../types';
import { ArrowLeft, CheckCircle, XCircle, BrainCircuit } from 'lucide-react';

export const QuizPage: React.FC = () => {
  const { addPoints, navigate, tasks } = useApp();
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [score, setScore] = useState(0);

  // Combine static mock quizzes with dynamic quizzes from tasks
  const taskQuizzes = tasks.filter(t => t.quiz).map(t => t.quiz as Quiz);
  const allQuizzes = [...MOCK_QUIZZES, ...taskQuizzes];

  const handleStartQuiz = (quiz: Quiz) => {
    setActiveQuiz(quiz);
    setAnswers({});
    setIsSubmitted(false);
    setScore(0);
    window.scrollTo(0, 0);
  };

  const handleSelectOption = (questionId: string, optionIndex: number) => {
    if (isSubmitted) return;
    setAnswers(prev => ({ ...prev, [questionId]: optionIndex }));
  };

  const handleSubmit = () => {
    if (!activeQuiz) return;
    
    // Check if all questions are answered
    if (Object.keys(answers).length < activeQuiz.questions.length) {
      alert("Please answer all questions before submitting.");
      return;
    }

    let correctCount = 0;
    activeQuiz.questions.forEach(q => {
      if (answers[q.id] === q.correctAnswer) {
        correctCount++;
      }
    });

    setScore(correctCount);
    setIsSubmitted(true);

    // Award points if score > 70%
    const percentage = (correctCount / activeQuiz.questions.length) * 100;
    if (percentage >= 70) {
      addPoints(activeQuiz.rewardPoints);
    }
  };

  const handleBack = () => {
    setActiveQuiz(null);
    setAnswers({});
    setIsSubmitted(false);
  };

  // List View
  if (!activeQuiz) {
    return (
      <div className="space-y-6">
        <div className="text-center mb-8">
           <h1 className="text-3xl font-bold font-display text-gray-900">Education Hub</h1>
           <p className="text-gray-500">Boost your eco-knowledge and earn points with these quizzes.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {allQuizzes.length === 0 && <div className="text-gray-500 col-span-2 text-center">No quizzes available at the moment.</div>}
          {allQuizzes.map(quiz => (
            <div key={quiz.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition">
              <div className="flex items-start justify-between mb-4">
                <div className="p-3 bg-purple-50 rounded-lg">
                  <BrainCircuit className="text-purple-600" size={24} />
                </div>
                <span className="bg-gold-100 text-gold-700 px-3 py-1 rounded-full text-xs font-bold">
                  {quiz.rewardPoints} PTS
                </span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{quiz.title}</h3>
              <p className="text-gray-600 mb-6">{quiz.description}</p>
              <button 
                onClick={() => handleStartQuiz(quiz)}
                className="w-full bg-forest-600 hover:bg-forest-700 text-white font-bold py-3 rounded-lg transition"
              >
                Start Quiz
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Active Quiz View
  return (
    <div className="max-w-2xl mx-auto">
      <button onClick={handleBack} className="flex items-center text-gray-500 hover:text-forest-600 mb-6 transition">
          <ArrowLeft size={20} className="mr-2" /> Back to Quizzes
      </button>

      <div className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden">
        <div className="bg-forest-600 p-6 text-white">
          <h2 className="text-2xl font-bold">{activeQuiz.title}</h2>
          <p className="opacity-90">{activeQuiz.questions.length} Questions • {activeQuiz.rewardPoints} Points Reward</p>
        </div>

        <div className="p-6 md:p-8 space-y-8">
          {activeQuiz.questions.map((q, idx) => {
             const userAnswer = answers[q.id];
             const isCorrect = userAnswer === q.correctAnswer;
             
             return (
              <div key={q.id} className="space-y-3">
                <h3 className="font-bold text-lg text-gray-800 flex gap-2">
                  <span className="text-forest-500">{idx + 1}.</span> {q.text}
                </h3>
                <div className="space-y-2 pl-4">
                  {q.options.map((opt, optIdx) => {
                    let optionClass = "border-gray-200 hover:bg-gray-50";
                    if (isSubmitted) {
                       if (optIdx === q.correctAnswer) optionClass = "bg-green-100 border-green-300 text-green-800";
                       else if (userAnswer === optIdx && userAnswer !== q.correctAnswer) optionClass = "bg-red-100 border-red-300 text-red-800";
                       else optionClass = "border-gray-200 opacity-50";
                    } else if (userAnswer === optIdx) {
                       optionClass = "bg-forest-50 border-forest-500 text-forest-700 ring-1 ring-forest-500";
                    }

                    return (
                      <button
                        key={optIdx}
                        onClick={() => handleSelectOption(q.id, optIdx)}
                        disabled={isSubmitted}
                        className={`w-full text-left p-3 rounded-lg border transition flex justify-between items-center ${optionClass}`}
                      >
                        <span>{opt}</span>
                        {isSubmitted && optIdx === q.correctAnswer && <CheckCircle size={16} className="text-green-600" />}
                        {isSubmitted && userAnswer === optIdx && userAnswer !== q.correctAnswer && <XCircle size={16} className="text-red-600" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        <div className="p-6 border-t border-gray-100 bg-gray-50">
          {!isSubmitted ? (
            <button 
              onClick={handleSubmit}
              className="w-full bg-forest-600 hover:bg-forest-700 text-white font-bold py-4 rounded-xl shadow-md transition text-lg"
            >
              Submit Quiz
            </button>
          ) : (
            <div className="text-center space-y-4">
              <div className="inline-block p-4 rounded-full bg-white shadow-sm">
                <span className="text-4xl font-extrabold text-forest-600">{score}</span>
                <span className="text-gray-400 text-xl"> / {activeQuiz.questions.length}</span>
              </div>
              
              <h3 className="text-xl font-bold text-gray-900">
                {score / activeQuiz.questions.length >= 0.7 ? "Excellent Work!" : "Keep Learning!"}
              </h3>
              
              {score / activeQuiz.questions.length >= 0.7 && (
                <div className="text-green-600 font-bold flex items-center justify-center gap-2">
                   <CheckCircle /> You earned {activeQuiz.rewardPoints} Green Points!
                </div>
              )}

              <div className="flex gap-4 pt-4">
                 <button onClick={handleBack} className="flex-1 bg-white border border-gray-300 text-gray-700 font-bold py-3 rounded-lg hover:bg-gray-50 transition">
                    Back to List
                 </button>
                 <button onClick={() => navigate('dashboard')} className="flex-1 bg-forest-600 text-white font-bold py-3 rounded-lg hover:bg-forest-700 transition">
                    Dashboard
                 </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};