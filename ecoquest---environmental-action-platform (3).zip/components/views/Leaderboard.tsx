import React from 'react';
import { useApp } from '../../AppContext';
import { Trophy, Medal } from 'lucide-react';
import { UserRole } from '../../types';

export const LeaderboardPage: React.FC = () => {
    const { user } = useApp();
    
    // Mock Leaderboard Data
    const baseLeaders = [
        { id: '1', name: 'Alex Johnson', points: 2450, school: 'Greenwood High' },
        { id: '2', name: 'Sarah Lee', points: 2100, school: 'Northside Academy' },
        { id: '3', name: 'Mike Chen', points: 1950, school: 'Greenwood High' },
        { id: '4', name: 'Emma Davis', points: 1200, school: 'West Valley' },
    ];

    // Add current user if student
    let allLeaders = [...baseLeaders];
    if (user && user.role !== UserRole.ADMIN) {
        allLeaders.push({
            id: user.id,
            name: user.name,
            points: user.points,
            school: 'Your School'
        });
    }

    // Sort descending
    const sortedLeaders = allLeaders.sort((a, b) => b.points - a.points);

    return (
        <div className="max-w-4xl mx-auto space-y-6">
            <div className="text-center mb-10">
                <h1 className="text-3xl font-bold text-gray-900 font-display">Top Eco-Warriors</h1>
                <p className="text-gray-500">See who is making the biggest impact this month.</p>
            </div>

            <div className="bg-white rounded-2xl shadow-lg overflow-hidden border border-gray-100">
                <div className="overflow-x-auto">
                    <table className="w-full">
                        <thead className="bg-gray-50 border-b border-gray-200">
                            <tr>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Rank</th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Student</th>
                                <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">School</th>
                                <th className="px-6 py-4 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Points</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {sortedLeaders.map((leader, index) => {
                                const isUser = user && leader.id === user.id;
                                return (
                                    <tr key={index} className={isUser ? "bg-forest-50" : "hover:bg-gray-50"}>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="flex items-center">
                                                {index === 0 && <Trophy className="text-gold-500 mr-2" size={20} />}
                                                {index === 1 && <Medal className="text-gray-400 mr-2" size={20} />}
                                                {index === 2 && <Medal className="text-orange-400 mr-2" size={20} />}
                                                <span className={`font-bold ${index < 3 ? 'text-gray-900' : 'text-gray-500'}`}>#{index + 1}</span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="font-medium text-gray-900">{leader.name} {isUser && '(You)'}</div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap">
                                            <div className="text-gray-500">{leader.school}</div>
                                        </td>
                                        <td className="px-6 py-4 whitespace-nowrap text-right">
                                            <div className="font-bold text-forest-600">{leader.points.toLocaleString()}</div>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};