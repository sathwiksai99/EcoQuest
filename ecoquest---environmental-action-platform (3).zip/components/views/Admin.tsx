import React, { useState } from 'react';
import { useApp } from '../../AppContext';
import { UserRole, UserStatus, Task, TaskDifficulty, Quiz } from '../../types';
import { generateTaskDescription, generateAiNotification, generateTaskQuiz, generateAiMessage } from '../../services/geminiService';
import { 
  Loader2, Sparkles, Plus, Zap, CheckCircle, XCircle, 
  Trash2, Edit, User, Shield, BarChart3, BellRing, Search, Lock, BrainCircuit, Mail, Send
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

export const AdminPage: React.FC = () => {
  const { user, users, tasks, addTask, updateTask, deleteTask, submissions, updateSubmission, updateUserStatus, updateUserRole, viewTask, messages, sendMessage } = useApp();
  const [activeTab, setActiveTab] = useState<'analytics' | 'tasks' | 'users' | 'verifications' | 'communication'>('analytics');
  
  if (user?.role !== UserRole.ADMIN && user?.role !== UserRole.EDUCATOR) {
      return <div className="text-center py-20 text-red-500 font-bold">Access Denied. Admins & Educators Only.</div>;
  }

  const isAdmin = user.role === UserRole.ADMIN;

  return (
    <div className="space-y-6">
        {/* Header Tabs */}
        <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex flex-wrap gap-2">
            <TabButton active={activeTab === 'analytics'} onClick={() => setActiveTab('analytics')} icon={<BarChart3 size={18} />} label="Analytics" />
            
            {/* Task Management is strictly for ADMINS */}
            {isAdmin && (
                <TabButton active={activeTab === 'tasks'} onClick={() => setActiveTab('tasks')} icon={<Edit size={18} />} label="Task Management" />
            )}
            
            <TabButton active={activeTab === 'users'} onClick={() => setActiveTab('users')} icon={<User size={18} />} label="User Management" />
            <TabButton active={activeTab === 'verifications'} onClick={() => setActiveTab('verifications')} icon={<Shield size={18} />} label="Verifications" count={submissions.filter(s => s.status === 'PENDING').length} />
            <TabButton active={activeTab === 'communication'} onClick={() => setActiveTab('communication')} icon={<Mail size={18} />} label="Communication" />
        </div>

        {/* Content Area */}
        <div className="min-h-[500px]">
            {activeTab === 'analytics' && <AnalyticsTab submissions={submissions} tasks={tasks} />}
            
            {activeTab === 'tasks' && (
                isAdmin 
                ? <TaskManagementTab tasks={tasks} onAdd={addTask} onUpdate={updateTask} onDelete={deleteTask} />
                : <div className="p-8 text-center text-gray-400 bg-gray-50 rounded-xl border border-gray-200">Task Management is restricted to Administrators.</div>
            )}
            
            {activeTab === 'users' && <UserManagementTab users={users} onUpdateStatus={updateUserStatus} onUpdateRole={updateUserRole} currentUserRole={user.role} />}
            {activeTab === 'verifications' && <VerificationsTab submissions={submissions} onVerify={updateSubmission} onViewTask={viewTask} tasks={tasks} />}
            {activeTab === 'communication' && <CommunicationTab messages={messages} onSend={sendMessage} />}
        </div>
    </div>
  );
};

const TabButton: React.FC<{ active: boolean; onClick: () => void; icon: React.ReactNode; label: string; count?: number }> = ({ active, onClick, icon, label, count }) => (
    <button 
        onClick={onClick}
        className={`flex items-center gap-2 px-4 py-2 rounded-lg font-bold transition ${active ? 'bg-forest-600 text-white shadow-md' : 'text-gray-600 hover:bg-gray-100'}`}
    >
        {icon}
        {label}
        {count !== undefined && count > 0 && <span className="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">{count}</span>}
    </button>
);

// --- ANALYTICS TAB ---
const AnalyticsTab: React.FC<{ submissions: any[], tasks: any[] }> = ({ submissions, tasks }) => {
    const [notification, setNotification] = useState('');
    const [isGenerating, setIsGenerating] = useState(false);

    const handleGenerateNotification = async () => {
        setIsGenerating(true);
        const note = await generateAiNotification("Student engagement and task completion");
        setNotification(note);
        setIsGenerating(false);
    };

    const statusData = [
        { name: 'Approved', value: submissions.filter(s => s.status === 'APPROVED').length, color: '#22c55e' },
        { name: 'Rejected', value: submissions.filter(s => s.status === 'REJECTED').length, color: '#ef4444' },
        { name: 'Pending', value: submissions.filter(s => s.status === 'PENDING').length, color: '#eab308' },
    ];

    // Safe data check
    const hasData = statusData.some(d => d.value > 0);

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Submission Status Overview</h3>
                <div className="h-64 flex items-center justify-center">
                    {hasData ? (
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie data={statusData} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value">
                                    {statusData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={entry.color} />
                                    ))}
                                </Pie>
                                <Tooltip />
                            </PieChart>
                        </ResponsiveContainer>
                    ) : (
                        <div className="text-gray-400 text-sm">No submission data available yet.</div>
                    )}
                </div>
                <div className="flex justify-center gap-4 text-sm font-medium mt-4">
                    {statusData.map(d => <div key={d.name} className="flex items-center gap-1"><div className="w-3 h-3 rounded-full" style={{backgroundColor: d.color}}></div>{d.name}: {d.value}</div>)}
                </div>
            </div>

            <div className="space-y-6">
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-bold text-gray-900 flex items-center gap-2">
                             <BellRing size={20} className="text-forest-500" /> AI Notification Manager
                        </h3>
                    </div>
                    <p className="text-gray-500 text-sm mb-4">Generate engaging reminders for your students using AI.</p>
                    
                    <button 
                        onClick={handleGenerateNotification} 
                        disabled={isGenerating}
                        className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold rounded-xl flex items-center justify-center gap-2 hover:shadow-lg transition"
                    >
                         {isGenerating ? <Loader2 className="animate-spin" /> : <Sparkles size={18} />} Generate Notification
                    </button>

                    {notification && (
                        <div className="mt-4 p-4 bg-purple-50 text-purple-900 rounded-xl border border-purple-200 animate-in fade-in">
                            <p className="font-medium">"{notification}"</p>
                            <div className="mt-2 text-xs text-purple-600 font-bold uppercase tracking-wide">Sent to all users</div>
                        </div>
                    )}
                </div>

                <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                    <h3 className="text-lg font-bold text-gray-900 mb-2">Platform Stats</h3>
                    <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-gray-50 rounded-xl">
                            <p className="text-gray-500 text-xs uppercase font-bold">Total Tasks</p>
                            <p className="text-2xl font-bold text-gray-900">{tasks.length}</p>
                        </div>
                         <div className="p-4 bg-gray-50 rounded-xl">
                            <p className="text-gray-500 text-xs uppercase font-bold">Verifications</p>
                            <p className="text-2xl font-bold text-gray-900">{submissions.length}</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

// --- TASK MANAGEMENT TAB ---
const TaskManagementTab: React.FC<{ tasks: Task[], onAdd: (t: Task) => void, onUpdate: (t: Task) => void, onDelete: (id: string) => void }> = ({ tasks, onAdd, onUpdate, onDelete }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [editId, setEditId] = useState<string | null>(null);
    const [formState, setFormState] = useState<Partial<Task>>({});
    const [isAiLoading, setIsAiLoading] = useState(false);
    const [topic, setTopic] = useState('');
    const [includeQuiz, setIncludeQuiz] = useState(false);

    const resetForm = () => {
        setFormState({});
        setEditId(null);
        setIsEditing(false);
        setTopic('');
        setIncludeQuiz(false);
    };

    const handleEdit = (task: Task) => {
        setFormState(task);
        setEditId(task.id);
        setIsEditing(true);
        setIncludeQuiz(!!task.quiz);
    };

    const handleGenerate = async () => {
        if (!topic) return;
        setIsAiLoading(true);
        
        // Generate Task Details
        const resultStr = await generateTaskDescription(topic);
        const result = JSON.parse(resultStr);
        
        let generatedQuiz: Quiz | undefined = undefined;
        if (includeQuiz) {
             const quizStr = await generateTaskQuiz(topic, TaskDifficulty.MEDIUM);
             const quizData = JSON.parse(quizStr);
             if (quizData.questions) {
                 generatedQuiz = {
                     id: `q_${Date.now()}`,
                     title: quizData.title || `${topic} Quiz`,
                     description: quizData.description || "Test your knowledge",
                     rewardPoints: 50,
                     questions: quizData.questions
                 };
             }
        }

        setFormState(prev => ({
            ...prev,
            title: result.title || topic,
            description: result.description || "Generated description",
            steps: result.steps || ["Step 1"],
            points: 100,
            difficulty: TaskDifficulty.MEDIUM,
            imageUrl: "https://picsum.photos/400/300",
            category: "General",
            locationRequired: false,
            quiz: generatedQuiz
        }));
        setIsAiLoading(false);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const taskData = {
            ...formState,
            id: editId || `t_${Date.now()}`,
            createdAt: formState.createdAt || Date.now()
        } as Task;

        if (editId) {
            onUpdate(taskData);
        } else {
            onAdd(taskData);
        }
        resetForm();
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Form Section */}
            <div className="lg:col-span-1 bg-white p-6 rounded-2xl shadow-sm border border-gray-100 h-fit">
                <h3 className="text-lg font-bold text-gray-900 mb-4">{isEditing ? 'Edit Task' : 'Create New Task'}</h3>
                
                {!isEditing && (
                    <div className="mb-6 p-4 bg-purple-50 rounded-xl border border-purple-100">
                        <label className="block text-xs font-bold text-purple-800 mb-2">AI Quick Generate</label>
                        <div className="space-y-2">
                             <div className="flex gap-2">
                                <input 
                                    value={topic} 
                                    onChange={(e) => setTopic(e.target.value)} 
                                    placeholder="Topic (e.g. Save Water)"
                                    className="flex-grow px-3 py-1.5 text-sm rounded border border-purple-200"
                                />
                                <button onClick={handleGenerate} disabled={isAiLoading} className="bg-purple-600 text-white p-2 rounded">
                                    {isAiLoading ? <Loader2 size={16} className="animate-spin"/> : <Sparkles size={16}/>}
                                </button>
                            </div>
                            <div className="flex items-center gap-2">
                                <input 
                                    type="checkbox" 
                                    id="genQuiz"
                                    checked={includeQuiz}
                                    onChange={e => setIncludeQuiz(e.target.checked)}
                                    className="rounded text-purple-600"
                                />
                                <label htmlFor="genQuiz" className="text-xs font-medium text-purple-800 cursor-pointer">Generate attached quiz</label>
                            </div>
                        </div>
                    </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-4">
                    <input 
                        required 
                        placeholder="Title" 
                        value={formState.title || ''} 
                        onChange={e => setFormState({...formState, title: e.target.value})}
                        className="w-full px-4 py-2 border rounded-lg text-sm"
                    />
                    <textarea 
                        required 
                        placeholder="Description" 
                        value={formState.description || ''} 
                        onChange={e => setFormState({...formState, description: e.target.value})}
                        className="w-full px-4 py-2 border rounded-lg text-sm h-24"
                    />
                    <div className="flex gap-2">
                        <input 
                            type="number" 
                            placeholder="Points" 
                            value={formState.points || ''} 
                            onChange={e => setFormState({...formState, points: parseInt(e.target.value)})}
                            className="w-1/2 px-4 py-2 border rounded-lg text-sm"
                        />
                         <select 
                            value={formState.difficulty || TaskDifficulty.MEDIUM}
                            onChange={e => setFormState({...formState, difficulty: e.target.value as TaskDifficulty})}
                            className="w-1/2 px-4 py-2 border rounded-lg text-sm"
                        >
                            <option value={TaskDifficulty.EASY}>Easy</option>
                            <option value={TaskDifficulty.MEDIUM}>Medium</option>
                            <option value={TaskDifficulty.HARD}>Hard</option>
                        </select>
                    </div>
                    
                    <div className="flex items-center gap-2">
                        <input 
                            type="checkbox" 
                            checked={formState.isPriority || false}
                            onChange={e => setFormState({...formState, isPriority: e.target.checked})}
                        />
                        <span className="text-sm font-medium">Startup Initiative (2x Points)</span>
                    </div>

                    {formState.quiz && (
                        <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg flex items-center gap-2 text-sm text-blue-800">
                            <BrainCircuit size={16} />
                            <span>Quiz Attached: {formState.quiz.title}</span>
                        </div>
                    )}

                    <div className="flex gap-2 pt-2">
                        <button type="submit" className="flex-1 bg-forest-600 text-white py-2 rounded-lg font-bold text-sm hover:bg-forest-700">
                            {isEditing ? 'Update Task' : 'Create Task'}
                        </button>
                        {isEditing && (
                            <button type="button" onClick={resetForm} className="px-4 py-2 border rounded-lg text-sm hover:bg-gray-50">
                                Cancel
                            </button>
                        )}
                    </div>
                </form>
            </div>

            {/* List Section */}
            <div className="lg:col-span-2 space-y-4">
                {tasks.map(task => (
                    <div key={task.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex justify-between items-center">
                        <div className="flex items-center gap-4">
                            <img src={task.imageUrl} alt="" className="w-12 h-12 rounded bg-gray-100 object-cover" />
                            <div>
                                <h4 className="font-bold text-gray-900">{task.title}</h4>
                                <div className="flex items-center gap-2 text-xs text-gray-500">
                                    <span className="bg-gray-100 px-2 py-0.5 rounded">{task.category}</span>
                                    <span>{task.points} pts</span>
                                    {task.isPriority && <Zap size={12} className="text-yellow-500" fill="currentColor"/>}
                                    {task.quiz && <BrainCircuit size={12} className="text-blue-500" />}
                                </div>
                            </div>
                        </div>
                        <div className="flex items-center gap-2">
                            <button onClick={() => handleEdit(task)} className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition">
                                <Edit size={18} />
                            </button>
                            <button onClick={() => onDelete(task.id)} className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition">
                                <Trash2 size={18} />
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

// --- USER MANAGEMENT TAB ---
const UserManagementTab: React.FC<{ users: any[], onUpdateStatus: (id: string, s: UserStatus) => void, onUpdateRole: (id: string, r: UserRole) => void, currentUserRole: UserRole }> = ({ users, onUpdateStatus, onUpdateRole, currentUserRole }) => {
    const [search, setSearch] = useState('');
    const filteredUsers = users.filter(u => u.name.toLowerCase().includes(search.toLowerCase()) || u.email.includes(search));
    const isAdmin = currentUserRole === UserRole.ADMIN;

    return (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="p-4 border-b border-gray-100 flex gap-4">
                <div className="relative flex-grow max-w-md">
                    <Search className="absolute left-3 top-3 text-gray-400" size={18} />
                    <input 
                        value={search}
                        onChange={e => setSearch(e.target.value)}
                        placeholder="Search users..."
                        className="w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-forest-500 outline-none"
                    />
                </div>
            </div>
            <table className="w-full text-sm text-left">
                <thead className="bg-gray-50 text-gray-500 font-medium">
                    <tr>
                        <th className="px-6 py-4">User</th>
                        <th className="px-6 py-4">Role</th>
                        <th className="px-6 py-4">Status</th>
                        <th className="px-6 py-4">Actions</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                    {filteredUsers.map(user => (
                        <tr key={user.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4">
                                <div className="font-bold text-gray-900">{user.name}</div>
                                <div className="text-gray-500 text-xs">{user.email}</div>
                            </td>
                            <td className="px-6 py-4">
                                {isAdmin ? (
                                    <select 
                                        value={user.role} 
                                        onChange={(e) => onUpdateRole(user.id, e.target.value as UserRole)}
                                        className="bg-gray-50 border border-gray-200 rounded px-2 py-1 text-xs"
                                    >
                                        <option value={UserRole.STUDENT}>Student</option>
                                        <option value={UserRole.EDUCATOR}>Educator</option>
                                        <option value={UserRole.ADMIN}>Admin</option>
                                    </select>
                                ) : (
                                    <span className="text-gray-600">{user.role}</span>
                                )}
                            </td>
                            <td className="px-6 py-4">
                                <span className={`px-2 py-1 rounded text-xs font-bold ${
                                    user.status === UserStatus.ACTIVE ? 'bg-green-100 text-green-700' :
                                    user.status === UserStatus.PENDING ? 'bg-yellow-100 text-yellow-700' :
                                    'bg-red-100 text-red-700'
                                }`}>
                                    {user.status}
                                </span>
                            </td>
                            <td className="px-6 py-4 flex gap-2">
                                {user.status === UserStatus.PENDING ? (
                                    <button 
                                        onClick={() => onUpdateStatus(user.id, UserStatus.ACTIVE)}
                                        className="text-green-600 font-bold text-xs hover:underline"
                                    >
                                        Approve
                                    </button>
                                ) : (
                                    <button 
                                        onClick={() => onUpdateStatus(user.id, user.status === UserStatus.ACTIVE ? UserStatus.SUSPENDED : UserStatus.ACTIVE)}
                                        className="text-gray-500 font-bold text-xs hover:underline"
                                    >
                                        {user.status === UserStatus.ACTIVE ? 'Suspend' : 'Reactivate'}
                                    </button>
                                )}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

// --- VERIFICATIONS TAB ---
const VerificationsTab: React.FC<{ submissions: any[], onVerify: (id: string, s: 'APPROVED' | 'REJECTED') => void, onViewTask: (id: string) => void, tasks: Task[] }> = ({ submissions, onVerify, onViewTask, tasks }) => {
    const pending = submissions.filter(s => s.status === 'PENDING');

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pending.length === 0 && (
                <div className="col-span-full text-center py-20 text-gray-400">
                    <CheckCircle size={48} className="mx-auto mb-4 opacity-20" />
                    No pending verifications.
                </div>
            )}
            {pending.map(sub => {
                const task = tasks.find(t => t.id === sub.taskId);
                const scoreColor = (sub.aiScore || 0) > 70 ? 'text-green-600' : (sub.aiScore || 0) > 40 ? 'text-yellow-600' : 'text-red-600';
                
                return (
                    <div key={sub.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
                        <div className="flex justify-between items-start mb-3">
                            <h4 className="font-bold text-gray-900 truncate pr-2">{task?.title}</h4>
                            <span className="bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded text-xs font-bold">Pending</span>
                        </div>
                        
                        <div className="relative h-48 bg-gray-100 rounded-lg mb-4 overflow-hidden group cursor-pointer" onClick={() => task && onViewTask(task.id)}>
                            <img src={sub.imageUrl} className="w-full h-full object-contain" alt="Proof"/>
                        </div>
                        
                         <div className="mb-4">
                            <p className="text-xs text-gray-500 font-bold uppercase">Student</p>
                            <p className="text-sm font-bold text-gray-800">{sub.userName || 'Unknown Student'}</p>
                            <p className="text-xs text-gray-400">{sub.userEmail}</p>
                        </div>

                        {sub.aiScore !== undefined && (
                            <div className="mb-4 p-3 bg-gray-50 rounded-lg text-sm">
                                <div className="flex justify-between font-bold mb-1">
                                    <span>AI Analysis</span>
                                    <span className={scoreColor}>{sub.aiScore}/100</span>
                                </div>
                                <p className="text-gray-500 text-xs">{sub.verificationNotes}</p>
                            </div>
                        )}

                        <div className="flex gap-2">
                            <button onClick={() => onVerify(sub.id, 'REJECTED')} className="flex-1 py-2 text-red-600 border border-red-200 rounded-lg hover:bg-red-50 font-bold text-sm">Reject</button>
                            <button onClick={() => onVerify(sub.id, 'APPROVED')} className="flex-1 py-2 bg-forest-600 text-white rounded-lg hover:bg-forest-700 font-bold text-sm">Approve</button>
                        </div>
                    </div>
                );
            })}
        </div>
    );
};

// --- COMMUNICATION TAB ---
const CommunicationTab: React.FC<{ messages: any[], onSend: (c: string, t: 'MANUAL' | 'AI') => void }> = ({ messages, onSend }) => {
    const [msgContent, setMsgContent] = useState('');
    const [aiTopic, setAiTopic] = useState('');
    const [mode, setMode] = useState<'MANUAL' | 'AI'>('MANUAL');
    const [isGenerating, setIsGenerating] = useState(false);

    const handleSend = () => {
        if (!msgContent) return;
        onSend(msgContent, mode);
        setMsgContent('');
        setAiTopic('');
        alert("Message Broadcasted!");
    };

    const handleAiGenerate = async () => {
        if (!aiTopic) return;
        setIsGenerating(true);
        const text = await generateAiMessage(aiTopic);
        setMsgContent(text);
        setIsGenerating(false);
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                <h3 className="text-lg font-bold text-gray-900 mb-6 flex items-center gap-2">
                    <Send size={20} className="text-blue-500" /> Broadcast Message
                </h3>
                
                <div className="flex bg-gray-100 p-1 rounded-lg mb-4">
                    <button onClick={() => setMode('MANUAL')} className={`flex-1 py-2 text-sm font-bold rounded-md ${mode === 'MANUAL' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500'}`}>Manual Type</button>
                    <button onClick={() => setMode('AI')} className={`flex-1 py-2 text-sm font-bold rounded-md ${mode === 'AI' ? 'bg-white shadow-sm text-purple-600' : 'text-gray-500'}`}>AI Generate</button>
                </div>

                {mode === 'AI' && (
                    <div className="mb-4 space-y-2">
                        <label className="text-xs font-bold text-purple-600 uppercase">Announcement Topic</label>
                        <div className="flex gap-2">
                            <input 
                                value={aiTopic}
                                onChange={(e) => setAiTopic(e.target.value)}
                                placeholder="e.g. Tree Planting Event next Friday"
                                className="flex-grow px-3 py-2 border rounded-lg text-sm"
                            />
                            <button onClick={handleAiGenerate} disabled={isGenerating} className="bg-purple-600 text-white px-3 rounded-lg">
                                {isGenerating ? <Loader2 className="animate-spin" size={16}/> : <Sparkles size={16}/>}
                            </button>
                        </div>
                    </div>
                )}

                <textarea 
                    value={msgContent}
                    onChange={(e) => setMsgContent(e.target.value)}
                    placeholder="Type your announcement here..."
                    className="w-full h-32 p-3 border rounded-lg text-sm mb-4"
                />

                <button onClick={handleSend} className="w-full bg-blue-600 text-white py-2 rounded-lg font-bold hover:bg-blue-700">
                    Send to All Students
                </button>
            </div>

            <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Sent History</h3>
                <div className="space-y-4 max-h-[400px] overflow-y-auto">
                    {messages.filter(m => m.sender === 'Admin').map(m => (
                        <div key={m.id} className="p-3 border rounded-lg text-sm bg-gray-50">
                            <p className="text-gray-800 mb-1">{m.content}</p>
                            <div className="flex justify-between text-xs text-gray-400">
                                <span>{new Date(m.timestamp).toLocaleDateString()}</span>
                                <span className={m.type === 'AI' ? 'text-purple-500 font-bold' : 'text-blue-500 font-bold'}>{m.type}</span>
                            </div>
                        </div>
                    ))}
                    {messages.length === 0 && <p className="text-gray-400 text-sm">No messages sent yet.</p>}
                </div>
            </div>
        </div>
    );
};