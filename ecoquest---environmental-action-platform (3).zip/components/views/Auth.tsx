import React, { useState } from 'react';
import { useApp } from '../../AppContext';
import { UserRole } from '../../types';
import { Shield, User as UserIcon, GraduationCap } from 'lucide-react';

interface AuthPageProps {
    initialRole?: UserRole;
    initialIsRegister?: boolean;
}

export const AuthPage: React.FC<AuthPageProps> = ({ initialRole = UserRole.STUDENT, initialIsRegister = false }) => {
  const { login } = useApp();
  const [isRegister, setIsRegister] = useState(initialIsRegister);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>(initialRole);
  const [isAdminMode, setIsAdminMode] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) return;
    
    // Determine role logic
    let finalRole = role;
    if (isAdminMode) {
        finalRole = UserRole.ADMIN;
    } else if (email.toLowerCase().includes('admin')) {
        // Fallback convenience for demo users who just type admin email
        finalRole = UserRole.ADMIN;
    }

    // Simulate auth delay
    setTimeout(() => {
      login(email, finalRole);
    }, 500);
  };

  return (
    <div className="max-w-md mx-auto bg-white p-8 rounded-2xl shadow-lg border border-gray-100 mt-10 relative transition-all duration-300">
      
      {/* Role Switcher Tab */}
      <div className="flex justify-center mb-6 bg-gray-100 p-1 rounded-lg">
          <button 
            onClick={() => { setIsAdminMode(false); setRole(UserRole.STUDENT); }}
            className={`flex-1 py-2 rounded-md text-sm font-bold transition flex items-center justify-center gap-2 ${!isAdminMode ? 'bg-white shadow-sm text-forest-700' : 'text-gray-500 hover:text-gray-700'}`}
          >
             <UserIcon size={16} /> User Portal
          </button>
          <button 
            onClick={() => {
                setIsAdminMode(true);
                setIsRegister(false);
                setEmail('admin@eco.com'); // Auto-fill for demo UX
                setPassword('admin123');
            }}
            className={`flex-1 py-2 rounded-md text-sm font-bold transition flex items-center justify-center gap-2 ${isAdminMode ? 'bg-white shadow-sm text-red-600' : 'text-gray-500 hover:text-gray-700'}`}
          >
             <Shield size={16} /> Admin
          </button>
      </div>

      <h2 className="text-2xl font-bold text-gray-900 mb-2 text-center font-display">
        {isAdminMode ? 'Admin Portal' : (isRegister ? `Create ${role === UserRole.EDUCATOR ? 'Educator' : 'Student'} Account` : 'Welcome Back')}
      </h2>
      <p className="text-center text-gray-500 text-sm mb-6">
          {isAdminMode ? 'Secure access for organization staff.' : (role === UserRole.EDUCATOR && isRegister ? 'Join as an Educator to manage tasks and students.' : 'Join the movement for a greener planet.')}
      </p>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
          <input 
            type="email" 
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 outline-none transition ${isAdminMode ? 'focus:ring-red-500 border-gray-300' : 'focus:ring-forest-500 border-gray-300'}`}
            placeholder={isAdminMode ? "admin@eco.com" : "you@school.edu"}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
          <input 
            type="password" 
            className={`w-full px-4 py-2 border rounded-lg focus:ring-2 outline-none transition ${isAdminMode ? 'focus:ring-red-500 border-gray-300' : 'focus:ring-forest-500 border-gray-300'}`}
            placeholder="••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        {isRegister && !isAdminMode && (
          <div className="animate-in slide-in-from-top-2 fade-in">
            <label className="block text-sm font-medium text-gray-700 mb-1">I am a...</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                className={`py-2 px-4 rounded-lg border flex items-center justify-center gap-2 transition ${role === UserRole.STUDENT ? 'bg-forest-50 border-forest-500 text-forest-700 font-bold' : 'border-gray-200 hover:bg-gray-50'}`}
                onClick={() => setRole(UserRole.STUDENT)}
              >
                <UserIcon size={16} /> Student
              </button>
              <button
                 type="button"
                 className={`py-2 px-4 rounded-lg border flex items-center justify-center gap-2 transition ${role === UserRole.EDUCATOR ? 'bg-forest-50 border-forest-500 text-forest-700 font-bold' : 'border-gray-200 hover:bg-gray-50'}`}
                 onClick={() => setRole(UserRole.EDUCATOR)}
              >
                <GraduationCap size={16} /> Educator
              </button>
            </div>
          </div>
        )}

        <button 
          type="submit" 
          className={`w-full font-bold py-3 rounded-lg transition shadow-md mt-4 text-white ${isAdminMode ? 'bg-gray-900 hover:bg-black' : 'bg-forest-600 hover:bg-forest-700'}`}
        >
          {isAdminMode ? 'Access Dashboard' : (isRegister ? 'Create Account' : 'Sign In')}
        </button>
      </form>

      {!isAdminMode && (
        <div className="mt-6 text-center text-sm text-gray-600">
            {isRegister ? "Already have an account? " : "New to EcoQuest? "}
            <button 
            onClick={() => setIsRegister(!isRegister)} 
            className="text-forest-600 font-bold hover:underline"
            >
            {isRegister ? 'Login here' : 'Register here'}
            </button>
        </div>
      )}

      {isAdminMode && (
         <div className="mt-6 text-center text-xs text-gray-400">
             Authorized personnel only. Use provided organization credentials.
         </div>
      )}
    </div>
  );
};