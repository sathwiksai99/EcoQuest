import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateTaskDescription = async (topic: string): Promise<string> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Create a detailed environmental task description for students based on the topic: "${topic}". 
      Include a title, a short engaging description, estimated time, and 3-5 step-by-step instructions. 
      Format as JSON.`,
      config: {
        responseMimeType: 'application/json'
      }
    });
    return response.text || "{}";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return JSON.stringify({ error: "Failed to generate task." });
  }
};

export const generateTaskQuiz = async (topic: string, difficulty: string): Promise<string> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Create a 3-question multiple choice quiz about "${topic}" suitable for a ${difficulty} level.
      
      Return JSON format matching this structure:
      {
        "title": "Short Quiz Title",
        "description": "Short description",
        "questions": [
          {
            "id": "q1",
            "text": "Question text?",
            "options": ["Option A", "Option B", "Option C", "Option D"],
            "correctAnswer": 0 // index of correct option
          }
        ]
      }`,
      config: {
        responseMimeType: 'application/json'
      }
    });
    return response.text || "{}";
  } catch (error) {
    console.error("Gemini Quiz API Error:", error);
    return "{}";
  }
};

export const verifyTaskEvidence = async (base64Image: string, taskDescription: string): Promise<{ verified: boolean; score: number; reason: string }> => {
  try {
    const prompt = `Analyze this image. The user is claiming to have completed the following environmental task: "${taskDescription}".
    1. Does the image provide visual evidence that this task was performed?
    2. Rate the quality/effort of the work from 0 to 100.
    
    Return JSON with fields: 
    - "verified" (boolean)
    - "score" (number 0-100)
    - "reason" (short string explaining the score and verification)`;

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: base64Image
            }
          },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: 'application/json'
      }
    });

    const result = JSON.parse(response.text || '{}');
    return {
        verified: result.verified ?? false,
        score: result.score ?? 0,
        reason: result.reason ?? "Unable to verify."
    };

  } catch (error) {
    console.error("Gemini Verification Error:", error);
    return { verified: false, score: 0, reason: "AI Service unavailable." };
  }
};

export const generateAiNotification = async (context: string): Promise<string> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Generate a short, motivating notification or reminder for students about: "${context}". 
      Keep it under 20 words. Emoji friendly.`,
    });
    return response.text || "Keep up the good work!";
  } catch (error) {
    return "Don't forget to complete your eco-tasks today!";
  }
};

export const generateAiMessage = async (topic: string): Promise<string> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Write a short, encouraging announcement (max 2 sentences) for a student environmental group about: "${topic}".`,
    });
    return response.text || "Stay green and clean!";
  } catch (error) {
      return "Announcement system unavailable.";
  }
};