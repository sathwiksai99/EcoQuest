import React from 'react';
import { AppProvider, useApp } from './AppContext';
import { Layout } from './components/Layout';
import { LandingPage } from './components/views/Landing';
import { AuthPage } from './components/views/Auth';
import { DashboardPage } from './components/views/Dashboard';
import { TasksPage } from './components/views/Tasks';
import { TaskDetailPage } from './components/views/TaskDetail';
import { AdminPage } from './components/views/Admin';
import { QuizPage } from './components/views/Quiz';
import { RewardsPage } from './components/views/Rewards';
import { LeaderboardPage } from './components/views/Leaderboard';
import { SettingsPage } from './components/views/Settings';
import { ProgramsPage } from './components/views/Programs';
import { LearnPage } from './components/views/Learn';
import { AchievementsPage } from './components/views/Achievements';
import { SupportPage } from './components/views/Support';
import { AlertTriangle } from 'lucide-react';
import { UserRole } from './types';

const ViewManager: React.FC = () => {
  const { currentView, user, navigate } = useApp();

  // Route protection
  if (!user && !['landing', 'login', 'register-student', 'register-educator', 'support'].includes(currentView)) {
      return <LandingPage />;
  }

  switch (currentView) {
    case 'landing': return <LandingPage />;
    case 'login': return <AuthPage />;
    case 'register-student': return <AuthPage initialRole={UserRole.STUDENT} initialIsRegister={true} />;
    case 'register-educator': return <AuthPage initialRole={UserRole.EDUCATOR} initialIsRegister={true} />;
    case 'dashboard': return <DashboardPage />;
    case 'tasks': return <TasksPage />;
    case 'task-detail': return <TaskDetailPage />;
    case 'admin': return <AdminPage />;
    case 'quizzes': return <QuizPage />;
    case 'rewards': return <RewardsPage />;
    case 'leaderboard': return <LeaderboardPage />;
    case 'settings': return <SettingsPage />;
    case 'programs': return <ProgramsPage />;
    case 'learn': return <LearnPage />;
    case 'achievements': return <AchievementsPage />;
    case 'support': return <SupportPage />;
    
    // Fallback for deprecated or unknown routes
    default: 
      return (
        <div className="text-center py-20">
          <AlertTriangle className="mx-auto h-12 w-12 text-yellow-500 mb-4" />
          <h2 className="text-2xl font-bold text-gray-900">Page Not Found</h2>
          <p className="text-gray-500 mb-6">The page you are looking for is not available.</p>
          <button 
            onClick={() => navigate('dashboard')}
            className="bg-forest-600 text-white px-6 py-2 rounded-lg font-bold"
          >
            Go to Dashboard
          </button>
        </div>
      );
  }
};

const App: React.FC = () => {
  return (
    <AppProvider>
      <Layout>
        <ViewManager />
      </Layout>
    </AppProvider>
  );
};

export default App;