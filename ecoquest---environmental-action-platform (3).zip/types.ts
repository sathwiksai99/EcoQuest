export enum UserRole {
  STUDENT = 'STUDENT',
  EDUCATOR = 'EDUCATOR',
  ADMIN = 'ADMIN'
}

export enum UserStatus {
  PENDING = 'PENDING',
  ACTIVE = 'ACTIVE',
  SUSPENDED = 'SUSPENDED'
}

export enum TaskDifficulty {
  EASY = 'Easy',
  MEDIUM = 'Medium',
  HARD = 'Hard'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  status: UserStatus;
  points: number;
  completedTaskIds: string[];
}

export interface QuizQuestion {
  id: string;
  text: string;
  options: string[];
  correctAnswer: number;
}

export interface Quiz {
  id: string;
  title: string;
  description: string;
  rewardPoints: number;
  questions: QuizQuestion[];
}

export interface Task {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: TaskDifficulty;
  points: number;
  locationRequired: boolean;
  latitude?: number;
  longitude?: number;
  steps: string[];
  imageUrl: string;
  isPriority?: boolean; 
  createdAt?: number;
  quiz?: Quiz; // Optional linked quiz
}

export interface Submission {
  id: string;
  taskId: string;
  userId: string;
  userName?: string;
  userEmail?: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  imageUrl: string;
  timestamp: number;
  verificationNotes?: string;
  aiScore?: number; // 0-100
  aiFeedback?: string;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  requiredPoints: number;
  category: 'Impact' | 'Learning' | 'Community';
}

export interface Reward {
  id: string;
  title: string;
  cost: number;
  description: string;
  type: 'COURSE' | 'DONATION' | 'ITEM';
}

export interface Meeting {
  id: string;
  title: string;
  platform: string;
  date: number;
  time: string;
  description: string;
  link: string;
}

export interface Competition {
  id: string;
  title: string;
  status: 'Active' | 'Upcoming' | 'Completed';
  description: string;
  prize: string;
  endDate: number;
}

export interface Message {
  id: string;
  sender: string;
  content: string;
  timestamp: number;
  type: 'MANUAL' | 'AI';
  isRead: boolean;
}

export interface Program {
  id: string;
  title: string;
  provider: string; // Government or Org Name
  description: string;
  requirements: string;
  minPoints: number;
  deadline: number;
  status: 'OPEN' | 'CLOSED';
  applicationStatus?: 'NONE' | 'APPLIED' | 'ACCEPTED' | 'REJECTED';
}

export interface LearningResource {
  id: string;
  title: string;
  type: 'ARTICLE' | 'VIDEO' | 'COURSE';
  category: string;
  description: string;
  url: string;
  thumbnailUrl: string;
  duration?: string; // e.g. "5 min read" or "10:00"
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}