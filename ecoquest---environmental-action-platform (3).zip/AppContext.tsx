import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Task, Submission, UserRole, UserStatus, Message, Program, LearningResource } from './types';
import { MOCK_TASKS, MOCK_MESSAGES, MOCK_PROGRAMS, MOCK_RESOURCES } from './constants';

interface AppState {
  user: User | null;
  users: User[]; // All users for admin
  tasks: Task[];
  submissions: Submission[];
  messages: Message[];
  programs: Program[];
  resources: LearningResource[];
  login: (email: string, role: UserRole) => void;
  logout: () => void;
  deleteAccount: () => void;
  addTask: (task: Task) => void;
  updateTask: (task: Task) => void;
  deleteTask: (taskId: string) => void;
  submitTask: (submission: Submission) => void;
  updateSubmission: (id: string, status: 'APPROVED' | 'REJECTED') => void;
  updateUserStatus: (userId: string, status: UserStatus) => void;
  updateUserRole: (userId: string, role: UserRole) => void;
  addPoints: (amount: number) => void;
  sendMessage: (content: string, type: 'MANUAL' | 'AI') => void;
  markMessageRead: (messageId: string) => void;
  deleteMessage: (messageId: string) => void;
  applyToProgram: (programId: string) => void;
  currentView: string;
  navigate: (view: string) => void;
  selectedTaskId: string | null;
  viewTask: (taskId: string) => void;
}

const AppContext = createContext<AppState | undefined>(undefined);

// Mock Users for Admin Management
const MOCK_USERS: User[] = [
    { id: 'u1', name: 'John Doe', email: 'john@student.edu', role: UserRole.STUDENT, status: UserStatus.ACTIVE, points: 1200, completedTaskIds: [] },
    { id: 'u2', name: 'Jane Smith', email: 'jane@student.edu', role: UserRole.STUDENT, status: UserStatus.PENDING, points: 0, completedTaskIds: [] },
    { id: 'u3', name: 'Mr. Anderson', email: 'anderson@school.edu', role: UserRole.EDUCATOR, status: UserStatus.ACTIVE, points: 0, completedTaskIds: [] },
];

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [tasks, setTasks] = useState<Task[]>(MOCK_TASKS);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [messages, setMessages] = useState<Message[]>(MOCK_MESSAGES);
  const [programs, setPrograms] = useState<Program[]>(MOCK_PROGRAMS);
  const [resources, setResources] = useState<LearningResource[]>(MOCK_RESOURCES);
  const [currentView, setCurrentView] = useState('landing');
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null);

  useEffect(() => {
    // Load from local storage
    const storedUser = localStorage.getItem('eco_user');
    const storedTasks = localStorage.getItem('eco_tasks');
    const storedUsers = localStorage.getItem('eco_users_db');
    const storedSubs = localStorage.getItem('eco_submissions');
    const storedMsgs = localStorage.getItem('eco_messages');
    const storedProgs = localStorage.getItem('eco_programs');

    if (storedUser) setUser(JSON.parse(storedUser));
    if (storedTasks) setTasks(JSON.parse(storedTasks));
    if (storedUsers) setUsers(JSON.parse(storedUsers));
    if (storedSubs) setSubmissions(JSON.parse(storedSubs));
    if (storedMsgs) setMessages(JSON.parse(storedMsgs));
    if (storedProgs) setPrograms(JSON.parse(storedProgs));
    
    if (storedUser) setCurrentView('dashboard');
  }, []);

  // Persistence Effects
  useEffect(() => {
    localStorage.setItem('eco_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('eco_users_db', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('eco_submissions', JSON.stringify(submissions));
  }, [submissions]);

  useEffect(() => {
    localStorage.setItem('eco_messages', JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem('eco_programs', JSON.stringify(programs));
  }, [programs]);

  const login = (email: string, role: UserRole) => {
    // Check if user exists in mock DB, if not create
    let existingUser = users.find(u => u.email === email);
    
    if (!existingUser) {
        existingUser = {
            id: 'u_' + Math.random().toString(36).substr(2, 9),
            name: email.split('@')[0],
            email,
            role,
            status: UserStatus.ACTIVE, // Auto active for demo
            points: 0,
            completedTaskIds: []
        };
        setUsers(prev => [...prev, existingUser!]);
    }

    setUser(existingUser);
    localStorage.setItem('eco_user', JSON.stringify(existingUser));
    setCurrentView('dashboard');
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('eco_user');
    setCurrentView('landing');
    setSelectedTaskId(null);
  };

  const deleteAccount = () => {
    if (!user) return;
    setUsers(prev => prev.filter(u => u.id !== user.id));
    setUser(null);
    localStorage.removeItem('eco_user');
    setCurrentView('landing');
  };

  const addTask = (task: Task) => {
    setTasks(prev => [task, ...prev]);
  };

  const updateTask = (updatedTask: Task) => {
    setTasks(prev => prev.map(t => t.id === updatedTask.id ? updatedTask : t));
  };

  const deleteTask = (taskId: string) => {
    setTasks(prev => prev.filter(t => t.id !== taskId));
  };

  const submitTask = (submission: Submission) => {
    setSubmissions(prev => [...prev, submission]);
  };

  const updateSubmission = (id: string, status: 'APPROVED' | 'REJECTED') => {
    // 1. Update submission status locally
    setSubmissions(prev => prev.map(sub => 
      sub.id === id ? { ...sub, status } : sub
    ));
    
    // 2. If APPROVED, calculate points and award to the specific user
    if (status === 'APPROVED') {
        const sub = submissions.find(s => s.id === id);
        if (sub) {
            const task = tasks.find(t => t.id === sub.taskId);
            if (task) {
                // Calculate points. If AI Score exists, use it. Otherwise 100%.
                let pointsToAward = task.points;
                if (sub.aiScore !== undefined) {
                    pointsToAward = Math.round(task.points * (sub.aiScore / 100));
                }

                // Update the user list (Mock DB)
                setUsers(prevUsers => prevUsers.map(u => {
                    if (u.id === sub.userId) {
                        return {
                            ...u,
                            points: u.points + pointsToAward,
                            completedTaskIds: [...u.completedTaskIds, task.id]
                        };
                    }
                    return u;
                }));

                // If the user being approved is the current session user, update session
                if (user && user.id === sub.userId) {
                     const updatedUser = { 
                         ...user, 
                         points: user.points + pointsToAward,
                         completedTaskIds: [...user.completedTaskIds, task.id]
                     };
                     setUser(updatedUser);
                     localStorage.setItem('eco_user', JSON.stringify(updatedUser));
                }
            }
        }
    }
  };

  const updateUserStatus = (userId: string, status: UserStatus) => {
      setUsers(prev => prev.map(u => u.id === userId ? { ...u, status } : u));
  };

  const updateUserRole = (userId: string, role: UserRole) => {
      setUsers(prev => prev.map(u => u.id === userId ? { ...u, role } : u));
      // Sync session if updating self
      if (user && user.id === userId) {
          const updatedUser = { ...user, role };
          setUser(updatedUser);
          localStorage.setItem('eco_user', JSON.stringify(updatedUser));
      }
  };

  const addPoints = (amount: number) => {
    if (!user) return;
    const updatedUser = { ...user, points: user.points + amount };
    setUser(updatedUser);
    // Also update in users list
    setUsers(prev => prev.map(u => u.id === user.id ? updatedUser : u));
    localStorage.setItem('eco_user', JSON.stringify(updatedUser));
  };

  const sendMessage = (content: string, type: 'MANUAL' | 'AI') => {
      const newMessage: Message = {
          id: Date.now().toString(),
          sender: 'Admin',
          content,
          timestamp: Date.now(),
          type,
          isRead: false
      };
      setMessages(prev => [newMessage, ...prev]);
  };

  const markMessageRead = (messageId: string) => {
      setMessages(prev => prev.map(m => m.id === messageId ? { ...m, isRead: true } : m));
  };

  const deleteMessage = (messageId: string) => {
      setMessages(prev => prev.filter(m => m.id !== messageId));
  };

  const applyToProgram = (programId: string) => {
    setPrograms(prev => prev.map(p => 
      p.id === programId ? { ...p, applicationStatus: 'APPLIED' } : p
    ));
    alert("Application submitted successfully!");
  };

  const navigate = (view: string) => {
    setCurrentView(view);
    window.scrollTo(0,0);
  };

  const viewTask = (taskId: string) => {
    setSelectedTaskId(taskId);
    navigate('task-detail');
  };

  return (
    <AppContext.Provider value={{ 
      user, 
      users,
      tasks, 
      submissions,
      messages,
      programs,
      resources,
      login, 
      logout,
      deleteAccount, 
      addTask,
      updateTask,
      deleteTask,
      submitTask, 
      updateSubmission,
      updateUserStatus,
      updateUserRole,
      addPoints,
      sendMessage,
      markMessageRead,
      deleteMessage,
      applyToProgram,
      currentView, 
      navigate,
      selectedTaskId,
      viewTask
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
};